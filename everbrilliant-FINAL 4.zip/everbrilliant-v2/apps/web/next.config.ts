import type { NextConfig } from 'next';
import bundleAnalyzer from '@next/bundle-analyzer';

const withBundleAnalyzer = bundleAnalyzer({
  enabled: process.env.ANALYZE === 'true',
});

const nextConfig: NextConfig = {
  // Standalone output for Docker
  output: 'standalone',

  // Transpile shared packages
  transpilePackages: ['@everbrilliant/ui', '@everbrilliant/types'],

  // Image optimization
  images: {
    domains: ['localhost'],
    formats: ['image/avif', 'image/webp'],
    minimumCacheTTL: 3600,
    deviceSizes: [390, 640, 768, 1024, 1280, 1920],
  },

  // Experimental features
  experimental: {
    optimizePackageImports: ['lucide-react', '@tanstack/react-query'],
    turbo: {},
  },

  // Webpack optimizations
  webpack(config, { isServer, dev }) {
    if (!dev && !isServer) {
      // Tree shaking
      config.optimization = {
        ...config.optimization,
        usedExports: true,
        sideEffects: true,

        splitChunks: {
          chunks: 'all',
          cacheGroups: {
            // Vendor chunk
            vendor: {
              test: /node_modules/,
              name: 'vendors',
              chunks: 'all',
              priority: 10,
            },
            // Realtime chunk (socket.io is heavy)
            realtime: {
              test: /socket\.io/,
              name: 'realtime',
              chunks: 'async',
              priority: 20,
            },
            // Charts chunk
            charts: {
              test: /recharts|chart\.js|d3/,
              name: 'charts',
              chunks: 'async',
              priority: 20,
            },
          },
        },
      };
    }
    return config;
  },

  // Headers for security + performance
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
        ],
      },
      {
        source: '/fonts/:path*',
        headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }],
      },
      {
        source: '/_next/static/:path*',
        headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }],
      },
    ];
  },

  // Redirects
  async redirects() {
    return [
      { source: '/', destination: '/dashboard', permanent: false },
    ];
  },
};

export default withBundleAnalyzer(nextConfig);
