import '@testing-library/jest-dom';
import { TextDecoder, TextEncoder } from 'util';

// Polyfills
global.TextEncoder = TextEncoder;
global.TextDecoder = TextDecoder as any;

// Mock Next.js router
jest.mock('next/navigation', () => ({
  useRouter: () => ({
    push: jest.fn(), replace: jest.fn(), back: jest.fn(),
    forward: jest.fn(), refresh: jest.fn(), prefetch: jest.fn(),
  }),
  usePathname: () => '/',
  useSearchParams: () => new URLSearchParams(),
  redirect: jest.fn(),
}));

// Mock socket
jest.mock('@/lib/socket/socket-client', () => ({
  socketManager: {
    connect: jest.fn(), disconnect: jest.fn(),
    on: jest.fn(() => jest.fn()),
    off: jest.fn(), emit: jest.fn(),
    isConnected: false,
  },
  WS_EVENTS: {
    NOTIFICATION: 'notification',
    APPROVAL_UPDATE: 'approval:update',
    PRESENCE_JOIN: 'presence:join',
  },
}));

// Suppress console errors in tests
const originalError = console.error;
beforeAll(() => {
  console.error = (...args: unknown[]) => {
    if (typeof args[0] === 'string' && args[0].includes('Warning:')) return;
    originalError(...args);
  };
});
afterAll(() => { console.error = originalError; });

// Auto-clear mocks
afterEach(() => { jest.clearAllMocks(); });
