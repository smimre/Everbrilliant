'use client';
import { usePathname, useRouter } from 'next/navigation';
import { useUIStore } from '@/store/ui.store';
import { useAuthStore } from '@/store/auth.store';
import { useLocaleStore } from '@/store/locale.store';
import { Avatar } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard, Inbox, ClipboardList, FileText, Building2,
  TrendingUp, Gavel, Link2, User, Settings, LogOut,
  BookOpen, Receipt, Package, Users, Landmark, BarChart3,
  Mail, CheckSquare, Calendar, Archive, GitBranch, ChevronDown,
} from 'lucide-react';
import { useState } from 'react';

interface NavItem {
  label: string;
  labelFa?: string;
  labelAr?: string;
  icon: React.ReactNode;
  href?: string;
  page?: string;
  badge?: number;
  children?: NavItem[];
}

const TRADING_NAV: NavItem[] = [
  { label: 'Dashboard', labelFa: 'داشبورد', icon: <LayoutDashboard className="h-4 w-4" />, href: '/dashboard' },
  { label: 'Inbox', labelFa: 'صندوق ورودی', icon: <Inbox className="h-4 w-4" />, href: '/dashboard/inbox', badge: 3 },
  { label: 'My Requests', labelFa: 'درخواست‌های من', icon: <ClipboardList className="h-4 w-4" />, href: '/dashboard/requests' },
  { label: 'Contracts', labelFa: 'قراردادها', icon: <FileText className="h-4 w-4" />, href: '/dashboard/contracts' },
  { label: 'CRM', labelFa: 'مشتریان', icon: <Building2 className="h-4 w-4" />, href: '/dashboard/crm' },
  { label: 'Tenders', labelFa: 'مناقصات', icon: <Gavel className="h-4 w-4" />, href: '/dashboard/tenders' },
  { label: 'Reports', labelFa: 'گزارشات', icon: <TrendingUp className="h-4 w-4" />, href: '/dashboard/reports' },
  { label: 'Connections', labelFa: 'اتصالات', icon: <Link2 className="h-4 w-4" />, href: '/dashboard/connections' },
];

const FINANCE_NAV: NavItem[] = [
  { label: 'Overview', labelFa: 'خلاصه', icon: <LayoutDashboard className="h-4 w-4" />, href: '/dashboard/finance' },
  {
    label: 'Accounting', labelFa: 'حسابداری', icon: <BookOpen className="h-4 w-4" />,
    children: [
      { label: 'Chart of Accounts', labelFa: 'سرفصل‌ها', icon: <ChevronDown className="h-3 w-3" />, href: '/dashboard/finance/coa' },
      { label: 'Journal', labelFa: 'روزنامه', icon: <ChevronDown className="h-3 w-3" />, href: '/dashboard/finance/journal' },
      { label: 'Ledger', labelFa: 'دفتر کل', icon: <ChevronDown className="h-3 w-3" />, href: '/dashboard/finance/ledger' },
    ],
  },
  { label: 'Invoices', labelFa: 'فاکتورها', icon: <Receipt className="h-4 w-4" />, href: '/dashboard/finance/invoices' },
  { label: 'Inventory', labelFa: 'انبارداری', icon: <Package className="h-4 w-4" />, href: '/dashboard/finance/inventory' },
  { label: 'HR / Payroll', labelFa: 'پرسنل', icon: <Users className="h-4 w-4" />, href: '/dashboard/finance/hr' },
  { label: 'Treasury', labelFa: 'خزانه', icon: <Landmark className="h-4 w-4" />, href: '/dashboard/finance/treasury' },
  { label: 'Reports', labelFa: 'گزارشات', icon: <BarChart3 className="h-4 w-4" />, href: '/dashboard/finance/reports' },
];

const AUTOMATION_NAV: NavItem[] = [
  { label: 'Dashboard', labelFa: 'داشبورد', icon: <LayoutDashboard className="h-4 w-4" />, href: '/dashboard/automation' },
  {
    label: 'Correspondence', labelFa: 'مکاتبات', icon: <Mail className="h-4 w-4" />,
    children: [
      { label: 'Inbox', labelFa: 'ورودی', icon: <ChevronDown className="h-3 w-3" />, href: '/dashboard/automation/inbox' },
      { label: 'Outbox', labelFa: 'خروجی', icon: <ChevronDown className="h-3 w-3" />, href: '/dashboard/automation/outbox' },
    ],
  },
  { label: 'Requests', labelFa: 'درخواست‌ها', icon: <CheckSquare className="h-4 w-4" />, href: '/dashboard/automation/requests' },
  { label: 'Meetings', labelFa: 'جلسات', icon: <Calendar className="h-4 w-4" />, href: '/dashboard/automation/meetings' },
  { label: 'Tasks', labelFa: 'وظایف', icon: <CheckSquare className="h-4 w-4" />, href: '/dashboard/automation/tasks' },
  { label: 'Archive', labelFa: 'آرشیو', icon: <Archive className="h-4 w-4" />, href: '/dashboard/automation/archive' },
  { label: 'Workflows', labelFa: 'گردش‌کار', icon: <GitBranch className="h-4 w-4" />, href: '/dashboard/automation/workflows' },
];

const MODULE_NAV = { trading: TRADING_NAV, finance: FINANCE_NAV, automation: AUTOMATION_NAV };

function NavItemComponent({ item, depth = 0 }: { item: NavItem; depth?: number }) {
  const pathname = usePathname();
  const router = useRouter();
  const { lang } = useLocaleStore();
  const [expanded, setExpanded] = useState(false);

  const label = lang === 'fa' ? (item.labelFa || item.label) : lang === 'ar' ? (item.labelAr || item.label) : item.label;
  const isActive = item.href ? pathname === item.href || pathname.startsWith(item.href + '/') : false;
  const hasChildren = item.children && item.children.length > 0;

  return (
    <div>
      <button
        onClick={() => {
          if (hasChildren) setExpanded(!expanded);
          else if (item.href) router.push(item.href);
        }}
        className={cn(
          'w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150',
          depth > 0 && 'ps-7 py-1.5',
          isActive
            ? 'bg-[hsl(var(--primary)/0.12)] text-[hsl(var(--primary))]'
            : 'text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] hover:bg-[hsl(var(--muted)/0.5)]'
        )}
      >
        <span className={cn('shrink-0', isActive ? 'text-[hsl(var(--primary))]' : 'opacity-60')}>{item.icon}</span>
        <span className="flex-1 truncate text-start">{label}</span>
        {item.badge !== undefined && item.badge > 0 && (
          <span className="rounded-full bg-[hsl(var(--primary))] text-white text-[10px] px-1.5 py-px min-w-[18px] text-center leading-tight">
            {item.badge > 99 ? '99+' : item.badge}
          </span>
        )}
        {hasChildren && (
          <ChevronDown className={cn('h-3.5 w-3.5 opacity-50 transition-transform shrink-0', expanded && 'rotate-180')} />
        )}
      </button>
      {hasChildren && expanded && (
        <div className="mt-0.5 space-y-0.5">
          {item.children!.map((child, i) => <NavItemComponent key={i} item={child} depth={depth + 1} />)}
        </div>
      )}
    </div>
  );
}

export function Sidebar() {
  const { sidebarOpen, activeModule } = useUIStore();
  const { user, clearAuth } = useAuthStore();
  const { lang } = useLocaleStore();
  const router = useRouter();

  const navItems = MODULE_NAV[activeModule] || TRADING_NAV;

  const handleLogout = () => {
    clearAuth();
    router.replace('/login');
  };

  return (
    <aside className={cn(
      'flex flex-col h-full bg-[hsl(var(--secondary))] border-e border-[hsl(var(--border))]',
      'transition-all duration-300 shrink-0',
      sidebarOpen ? 'w-60' : 'w-0 overflow-hidden'
    )}>
      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
        {navItems.map((item, i) => <NavItemComponent key={i} item={item} />)}
      </nav>

      {/* User Footer */}
      {user && (
        <div className="border-t border-[hsl(var(--border))] p-3">
          <div className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-[hsl(var(--muted)/0.5)] group cursor-pointer">
            <Avatar name={user.name} size="sm" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-[hsl(var(--foreground))] truncate">{user.name}</p>
              <p className="text-xs text-[hsl(var(--muted-foreground))] truncate">{user.role}</p>
            </div>
          </div>
          <div className="flex gap-1 mt-1">
            <button
              onClick={() => router.push('/dashboard/settings')}
              className="flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] rounded-lg hover:bg-[hsl(var(--muted)/0.5)] transition-colors"
            >
              <Settings className="h-3.5 w-3.5" />
              {lang === 'fa' ? 'تنظیمات' : 'Settings'}
            </button>
            <button
              onClick={handleLogout}
              className="flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs text-[hsl(var(--destructive))] hover:bg-[hsl(var(--destructive)/0.08)] rounded-lg transition-colors"
            >
              <LogOut className="h-3.5 w-3.5" />
              {lang === 'fa' ? 'خروج' : 'Logout'}
            </button>
          </div>
        </div>
      )}
    </aside>
  );
}
