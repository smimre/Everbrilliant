import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';
import type { User } from '@/types';

interface AuthState {
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

interface AuthActions {
  setAuth: (user: User, accessToken: string, refreshToken?: string) => void;
  clearAuth: () => void;
  setLoading: (loading: boolean) => void;
  updateUser: (updates: Partial<User>) => void;
  hasPermission: (permission: string) => boolean;
  hasRole: (role: string) => boolean;
  isAdmin: () => boolean;
}

type AuthStore = AuthState & AuthActions;

const INITIAL_STATE: AuthState = {
  user: null,
  accessToken: null,
  refreshToken: null,
  isAuthenticated: false,
  isLoading: false,
};

export const useAuthStore = create<AuthStore>()(
  persist(
    immer((set, get) => ({
      ...INITIAL_STATE,

      setAuth: (user, accessToken, refreshToken) => set((state) => {
        state.user = user;
        state.accessToken = accessToken;
        state.refreshToken = refreshToken ?? null;
        state.isAuthenticated = true;
        state.isLoading = false;
      }),

      clearAuth: () => set((state) => {
        Object.assign(state, INITIAL_STATE);
      }),

      setLoading: (isLoading) => set((state) => { state.isLoading = isLoading; }),

      updateUser: (updates) => set((state) => {
        if (state.user) Object.assign(state.user, updates);
      }),

      hasPermission: (permission) => {
        const { user } = get();
        if (!user) return false;
        if (get().isAdmin()) return true;
        return user.permissions.includes(permission);
      },

      hasRole: (role) => get().user?.role === role,

      isAdmin: () => {
        const role = get().user?.role;
        return role === 'company_admin' || role === 'sys_admin';
      },
    })),
    {
      name: 'eb-auth',
      storage: createJSONStorage(() => (typeof window !== 'undefined' ? localStorage : { getItem: () => null, setItem: () => {}, removeItem: () => {} })),
      partialize: (s) => ({
        user: s.user,
        accessToken: s.accessToken,
        refreshToken: s.refreshToken,
        isAuthenticated: s.isAuthenticated,
      }),
    }
  )
);
