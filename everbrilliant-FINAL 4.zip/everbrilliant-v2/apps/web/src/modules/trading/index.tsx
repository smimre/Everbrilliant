'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { useRequests, useContracts, useTenders } from '@/hooks/use-trading';
import { Table, Column } from '@/components/ui/table';
import { StatusBadge } from '@/components/dashboard/status-badge';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { StatCard } from '@/components/dashboard/stat-card';
import { Pagination } from '@/components/ui/pagination';
import type { TradeRequest, Contract, Tender } from '@/types';
import { Plus, Search, ClipboardList, FileText, Gavel, Link2 } from 'lucide-react';

type TradingView = 'dashboard' | 'requests' | 'contracts' | 'tenders' | 'connections';

interface TradingModuleProps {
  initialView?: TradingView;
}

export function TradingModule({ initialView = 'dashboard' }: TradingModuleProps) {
  const [view, setView] = useState<TradingView>(initialView);
  const { lang } = useLocaleStore();

  const views: Record<TradingView, React.ReactNode> = {
    dashboard:   <TradingDashboard onNavigate={setView} />,
    requests:    <RequestsList />,
    contracts:   <ContractsList />,
    tenders:     <TendersList />,
    connections: <ConnectionsPage />,
  };

  return (
    <div className="space-y-5">
      {view !== 'dashboard' && (
        <Button variant="ghost" onClick={() => setView('dashboard')}>
          ← {lang === 'fa' ? 'داشبورد' : 'Dashboard'}
        </Button>
      )}
      {views[view]}
    </div>
  );
}

function TradingDashboard({ onNavigate }: { onNavigate: (v: TradingView) => void }) {
  const { lang } = useLocaleStore();
  const { data: reqs } = useRequests({ limit: 100 });
  const pending = reqs?.data?.filter((r: any) => r.status === 'pending').length ?? 0;
  const completed = reqs?.data?.filter((r: any) => r.status === 'completed').length ?? 0;

  const navItems = [
    { icon: <ClipboardList className="h-6 w-6"/>, label_fa:'درخواست‌ها', label_en:'Requests', view:'requests' as TradingView, color:'#3b82f6', count: reqs?.total },
    { icon: <FileText className="h-6 w-6"/>, label_fa:'قراردادها', label_en:'Contracts', view:'contracts' as TradingView, color:'#8b5cf6' },
    { icon: <Gavel className="h-6 w-6"/>, label_fa:'مزایده‌ها', label_en:'Tenders', view:'tenders' as TradingView, color:'#f59e0b' },
    { icon: <Link2 className="h-6 w-6"/>, label_fa:'اتصالات', label_en:'Connections', view:'connections' as TradingView, color:'#10b981' },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">🏪 {lang === 'fa' ? 'بازرگانی' : 'Trading'}</h1>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title={lang==='fa'?'کل درخواست‌ها':'Total Requests'} value={reqs?.total??0} icon="📋" />
        <StatCard title={lang==='fa'?'در انتظار':'Pending'} value={pending} icon="⏳" color="warning" />
        <StatCard title={lang==='fa'?'تکمیل شده':'Completed'} value={completed} icon="✅" color="success" />
        <StatCard title={lang==='fa'?'قراردادها':'Contracts'} value={0} icon="📝" />
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {navItems.map(item => (
          <button key={item.view} onClick={() => onNavigate(item.view)}
            className="flex flex-col items-center gap-3 p-6 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] hover:border-[hsl(var(--primary)/0.4)] hover:shadow-md transition-all group">
            <div className="rounded-xl p-3 group-hover:scale-110 transition-transform" style={{ background:`${item.color}18`, color:item.color }}>
              {item.icon}
            </div>
            <span className="font-semibold text-sm">{lang==='fa'?item.label_fa:item.label_en}</span>
            {item.count !== undefined && <Badge>{item.count}</Badge>}
          </button>
        ))}
      </div>
    </div>
  );
}

function RequestsList() {
  const { lang } = useLocaleStore();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const { data, isLoading } = useRequests({ page, limit: 20, search });

  const columns: Column<TradeRequest>[] = [
    { key: 'id',       header: lang==='fa'?'شناسه':'ID',       width: 'w-28' },
    { key: 'product',  header: lang==='fa'?'کالا':'Product',    render: (v) => <span className="font-semibold">{v as string}</span> },
    { key: 'qty',      header: lang==='fa'?'مقدار':'Qty',       render: (v,r) => `${v} ${(r as any).unit}` },
    { key: 'status',   header: lang==='fa'?'وضعیت':'Status',    render: (v) => <StatusBadge status={v as string} lang={lang} /> },
    { key: 'priority', header: lang==='fa'?'اولویت':'Priority', render: (v) => <Badge>{v as string}</Badge> },
    { key: 'createdAt',header: lang==='fa'?'تاریخ':'Date',      render: (v) => new Date(v as string).toLocaleDateString(lang==='fa'?'fa-IR':'en-US') },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">{lang==='fa'?'درخواست‌های تجاری':'Trade Requests'}</h2>
        <Button size="sm"><Plus className="h-4 w-4"/>{lang==='fa'?'درخواست جدید':'New Request'}</Button>
      </div>
      <div className="relative">
        <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[hsl(var(--muted-foreground))]"/>
        <input value={search} onChange={e => setSearch(e.target.value)}
          placeholder={lang==='fa'?'جستجو...':'Search...'}
          className="w-full ps-9 pe-4 py-2 text-sm rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] focus:outline-none focus:border-[hsl(var(--primary))]"/>
      </div>
      <Table columns={columns} data={data?.data??[]} loading={isLoading}
        emptyTitle={lang==='fa'?'درخواستی یافت نشد':'No requests found'} />
      {data && <Pagination page={page} totalPages={Math.ceil((data.total||0)/20)} onPageChange={setPage} />}
    </div>
  );
}

function ContractsList() {
  const { lang } = useLocaleStore();
  const { data, isLoading } = useContracts();
  const columns: Column<Contract>[] = [
    { key: 'id',     header: 'ID',    width: 'w-36' },
    { key: 'title',  header: lang==='fa'?'عنوان':'Title', render: (v) => <span className="font-semibold">{v as string}</span> },
    { key: 'status', header: lang==='fa'?'وضعیت':'Status', render: (v) => <StatusBadge status={v as string} lang={lang} /> },
    { key: 'createdAt', header: lang==='fa'?'تاریخ':'Date', render: (v) => new Date(v as string).toLocaleDateString(lang==='fa'?'fa-IR':'en-US') },
  ];
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">{lang==='fa'?'قراردادها':'Contracts'}</h2>
        <Button size="sm"><Plus className="h-4 w-4"/>{lang==='fa'?'قرارداد جدید':'New Contract'}</Button>
      </div>
      <Table columns={columns} data={data?.data??[]} loading={isLoading}
        emptyTitle={lang==='fa'?'قراردادی یافت نشد':'No contracts found'} />
    </div>
  );
}

function TendersList() {
  const { lang } = useLocaleStore();
  const { data, isLoading } = useTenders();
  const columns: Column<Tender>[] = [
    { key: 'id',       header: 'ID',     width: 'w-36' },
    { key: 'title',    header: lang==='fa'?'عنوان':'Title', render: (v) => <span className="font-semibold">{v as string}</span> },
    { key: 'type',     header: lang==='fa'?'نوع':'Type' },
    { key: 'status',   header: lang==='fa'?'وضعیت':'Status', render: (v) => <StatusBadge status={v as string} lang={lang} /> },
    { key: 'endDate',  header: lang==='fa'?'پایان':'End Date', render: (v) => v ? new Date(v as string).toLocaleDateString(lang==='fa'?'fa-IR':'en-US') : '-' },
  ];
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">{lang==='fa'?'مزایده‌ها':'Tenders'}</h2>
        <Button size="sm"><Plus className="h-4 w-4"/>{lang==='fa'?'مزایده جدید':'New Tender'}</Button>
      </div>
      <Table columns={columns} data={data?.data??[]} loading={isLoading}
        emptyTitle={lang==='fa'?'مزایده‌ای یافت نشد':'No tenders found'} />
    </div>
  );
}

function ConnectionsPage() {
  const { lang } = useLocaleStore();
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">{lang==='fa'?'شرکت‌های متصل':'Connected Companies'}</h2>
      <div className="rounded-xl border border-dashed border-[hsl(var(--border))] p-12 text-center">
        <p className="text-4xl mb-3">🔗</p>
        <p className="font-semibold mb-2">{lang==='fa'?'هنوز اتصالی ندارید':'No connections yet'}</p>
        <p className="text-sm text-[hsl(var(--muted-foreground))] mb-4">{lang==='fa'?'با کد دعوت به شرکت‌های دیگر وصل شوید':'Connect with other companies using invite codes'}</p>
        <Button><Plus className="h-4 w-4"/>{lang==='fa'?'اتصال جدید':'New Connection'}</Button>
      </div>
    </div>
  );
}
