'use client';
import { useRouter } from 'next/navigation';
import { useLocaleStore } from '@/store/locale.store';
import { useUIStore } from '@/store/ui.store';
import { Plus, FileText, Receipt, Users, Gavel, Mail } from 'lucide-react';

const ACTIONS = {
  en: [
    { icon: <Plus className="h-5 w-5"/>, label: 'New Request', color: '#3b82f6', href: '/dashboard/requests/new' },
    { icon: <Receipt className="h-5 w-5"/>, label: 'New Invoice', color: '#10b981', href: '/dashboard/finance/invoices/new' },
    { icon: <FileText className="h-5 w-5"/>, label: 'New Contract', color: '#8b5cf6', href: '/dashboard/contracts/new' },
    { icon: <Gavel className="h-5 w-5"/>, label: 'New Tender', color: '#f59e0b', href: '/dashboard/tenders/new' },
    { icon: <Users className="h-5 w-5"/>, label: 'Add Employee', color: '#06b6d4', href: '/dashboard/finance/hr/new' },
    { icon: <Mail className="h-5 w-5"/>, label: 'New Letter', color: '#ec4899', href: '/dashboard/automation/letters/new' },
  ],
  fa: [
    { icon: <Plus className="h-5 w-5"/>, label: 'درخواست جدید', color: '#3b82f6', href: '/dashboard/requests/new' },
    { icon: <Receipt className="h-5 w-5"/>, label: 'فاکتور جدید', color: '#10b981', href: '/dashboard/finance/invoices/new' },
    { icon: <FileText className="h-5 w-5"/>, label: 'قرارداد جدید', color: '#8b5cf6', href: '/dashboard/contracts/new' },
    { icon: <Gavel className="h-5 w-5"/>, label: 'مزایده جدید', color: '#f59e0b', href: '/dashboard/tenders/new' },
    { icon: <Users className="h-5 w-5"/>, label: 'کارمند جدید', color: '#06b6d4', href: '/dashboard/finance/hr/new' },
    { icon: <Mail className="h-5 w-5"/>, label: 'مکاتبه جدید', color: '#ec4899', href: '/dashboard/automation/letters/new' },
  ],
};

export function QuickActionsWidget() {
  const { lang } = useLocaleStore();
  const router = useRouter();
  const actions = ACTIONS[lang as keyof typeof ACTIONS] || ACTIONS.en;
  const title = lang === 'fa' ? '⚡ دسترسی سریع' : lang === 'ar' ? '⚡ وصول سريع' : '⚡ Quick Actions';

  return (
    <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4">
      <h2 className="font-semibold mb-4">{title}</h2>
      <div className="grid grid-cols-2 gap-2">
        {actions.map((a, i) => (
          <button key={i} onClick={() => router.push(a.href)}
            className="flex flex-col items-center gap-2 p-3 rounded-xl border border-[hsl(var(--border))] hover:border-[hsl(var(--primary)/0.4)] hover:bg-[hsl(var(--muted)/0.5)] transition-all group"
          >
            <div className="rounded-xl p-2 group-hover:scale-110 transition-transform" style={{ background: `${a.color}18`, color: a.color }}>
              {a.icon}
            </div>
            <span className="text-xs font-medium text-center leading-tight text-[hsl(var(--muted-foreground))] group-hover:text-[hsl(var(--foreground))]">
              {a.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
