export { DashboardModule } from './index';
