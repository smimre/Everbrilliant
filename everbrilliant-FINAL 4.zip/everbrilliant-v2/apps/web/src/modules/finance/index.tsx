'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { InvoiceListPage } from './components/invoice-list';
import { InvoiceDetailPage } from './components/invoice-detail';
import { InvoiceCreatePage } from './components/invoice-create';
import { HRPage } from './components/hr';
import { InventoryPage } from './components/inventory';
import { TreasuryPage } from './components/treasury';
import { AccountingPage } from './components/accounting';
import { FinanceDashboard } from './components/finance-dashboard';

export type FinancePage = 'dashboard' | 'invoices' | 'invoice-detail' | 'invoice-create' | 'hr' | 'inventory' | 'treasury' | 'accounting' | 'reports';

interface FinanceModuleProps {
  initialPage?: FinancePage;
  invoiceId?: string;
}

export function FinanceModule({ initialPage = 'dashboard', invoiceId }: FinanceModuleProps) {
  const [page, setPage] = useState<FinancePage>(initialPage);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | undefined>(invoiceId);

  const navigate = (p: FinancePage, id?: string) => {
    setPage(p);
    if (id) setSelectedInvoiceId(id);
  };

  switch (page) {
    case 'invoices':        return <InvoiceListPage onSelect={(id) => navigate('invoice-detail', id)} onCreate={() => navigate('invoice-create')} />;
    case 'invoice-detail':  return <InvoiceDetailPage invoiceId={selectedInvoiceId!} onBack={() => navigate('invoices')} />;
    case 'invoice-create':  return <InvoiceCreatePage onBack={() => navigate('invoices')} onCreated={(id) => navigate('invoice-detail', id)} />;
    case 'hr':              return <HRPage />;
    case 'inventory':       return <InventoryPage />;
    case 'treasury':        return <TreasuryPage />;
    case 'accounting':      return <AccountingPage />;
    default:                return <FinanceDashboard navigate={navigate} />;
  }
}
