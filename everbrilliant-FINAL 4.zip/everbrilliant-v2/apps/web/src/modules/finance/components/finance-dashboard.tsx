'use client';
import { useLocaleStore } from '@/store/locale.store';
import { useInvoices, useEmployees, useInventory } from '@/hooks/use-finance';
import { StatCard } from '@/components/dashboard/stat-card';
import { StatusBadge } from '@/components/dashboard/status-badge';
import { Button } from '@/components/ui/button';
import { SkeletonCard } from '@/components/ui/skeleton';
import type { FinancePage } from '../index';
import { Receipt, Users, Package, TrendingUp, Landmark, BarChart3 } from 'lucide-react';

const T = {
  en: { title:'Finance Overview', paidInv:'Paid Invoices', unpaidInv:'Unpaid', overdueInv:'Overdue',
    employees:'Employees', inventory:'Inventory Items', quickNav:'Quick Navigation',
    accounting:'Accounting', invoices:'Invoices', hr:'HR & Payroll', treasury:'Treasury', reports:'Reports' },
  fa: { title:'داشبورد مالی', paidInv:'فاکتور پرداخت‌شده', unpaidInv:'پرداخت‌نشده', overdueInv:'معوق',
    employees:'کارمندان', inventory:'اقلام انبار', quickNav:'دسترسی سریع',
    accounting:'حسابداری', invoices:'فاکتورها', hr:'پرسنل', treasury:'خزانه', reports:'گزارشات' },
  ar: { title:'لوحة المالية', paidInv:'فواتير مدفوعة', unpaidInv:'غير مدفوعة', overdueInv:'متأخرة',
    employees:'الموظفون', inventory:'مخزون', quickNav:'وصول سريع',
    accounting:'المحاسبة', invoices:'الفواتير', hr:'الموارد البشرية', treasury:'الخزينة', reports:'التقارير' },
};

export function FinanceDashboard({ navigate }: { navigate: (p: FinancePage) => void }) {
  const { lang } = useLocaleStore();
  const t = T[lang as keyof typeof T] || T.en;
  const { data: invData, isLoading: invLoading } = useInvoices({ limit: 100 });
  const { data: empData, isLoading: empLoading } = useEmployees();
  const { data: invtData } = useInventory();

  const invoices = invData?.data ?? [];
  const paid = invoices.filter(i => i.status === 'paid').reduce((s, i) => s + i.total, 0);
  const unpaid = invoices.filter(i => ['sent','partial'].includes(i.status)).length;
  const overdue = invoices.filter(i => i.status === 'overdue').length;
  const fmt = (n: number) => new Intl.NumberFormat(lang === 'fa' ? 'fa-IR' : 'en-US').format(Math.round(n / 1_000_000)) + 'M';

  const navItems = [
    { icon: '📚', label: t.accounting, page: 'accounting' as FinancePage, color: '#3b82f6' },
    { icon: '🧾', label: t.invoices,   page: 'invoices'   as FinancePage, color: '#10b981' },
    { icon: '📦', label: t.inventory,  page: 'inventory'  as FinancePage, color: '#f59e0b' },
    { icon: '👥', label: t.hr,         page: 'hr'         as FinancePage, color: '#8b5cf6' },
    { icon: '🏦', label: t.treasury,   page: 'treasury'   as FinancePage, color: '#06b6d4' },
    { icon: '📊', label: t.reports,    page: 'reports'    as FinancePage, color: '#ec4899' },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">💰 {t.title}</h1>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <StatCard icon={<TrendingUp className="h-5 w-5"/>} label={t.paidInv}
          value={invLoading ? '...' : fmt(paid)} color="#10b981" loading={invLoading} />
        <StatCard icon={<Receipt className="h-5 w-5"/>} label={t.unpaidInv}
          value={unpaid} changeType={unpaid > 0 ? 'down' : 'neutral'} color="#f59e0b" />
        <StatCard icon={<Receipt className="h-5 w-5"/>} label={t.overdueInv}
          value={overdue} changeType={overdue > 0 ? 'down' : 'up'} color="#ef4444" />
        <StatCard icon={<Users className="h-5 w-5"/>} label={t.employees}
          value={empData?.total ?? 0} color="#8b5cf6" loading={empLoading} />
        <StatCard icon={<Package className="h-5 w-5"/>} label={t.inventory}
          value={invtData?.total ?? 0} color="#06b6d4" />
      </div>

      {/* Quick Nav */}
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-5">
        <h2 className="font-semibold mb-4">{t.quickNav}</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {navItems.map((item) => (
            <button key={item.page} onClick={() => navigate(item.page)}
              className="flex flex-col items-center gap-2.5 p-4 rounded-xl border border-[hsl(var(--border))] hover:border-[hsl(var(--primary)/0.4)] hover:bg-[hsl(var(--muted)/0.4)] transition-all group"
            >
              <span className="text-3xl group-hover:scale-110 transition-transform">{item.icon}</span>
              <span className="text-xs font-semibold text-center text-[hsl(var(--muted-foreground))] group-hover:text-[hsl(var(--foreground))]">
                {item.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Invoices */}
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[hsl(var(--border))]">
          <h2 className="font-semibold">🧾 {t.invoices}</h2>
          <Button variant="ghost" size="sm" onClick={() => navigate('invoices')}>
            {lang === 'fa' ? 'مشاهده همه' : 'View All'} →
          </Button>
        </div>
        <div className="divide-y divide-[hsl(var(--border))]">
          {invoices.slice(0, 5).map(inv => (
            <div key={inv.id} onClick={() => navigate('invoice-detail')}
              className="flex items-center gap-4 px-5 py-3 hover:bg-[hsl(var(--muted)/0.4)] cursor-pointer transition-colors"
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-mono font-semibold text-[hsl(var(--primary))]">{inv.id}</p>
                <p className="text-xs text-[hsl(var(--muted-foreground))]">{inv.issuedAt}</p>
              </div>
              <div className="text-end">
                <p className="text-sm font-bold tabular-nums">{fmt(inv.total)}</p>
                <p className="text-xs text-[hsl(var(--muted-foreground))]">IRR</p>
              </div>
              <StatusBadge status={inv.status} lang={lang} />
            </div>
          ))}
          {invoices.length === 0 && (
            <div className="py-12 text-center text-sm text-[hsl(var(--muted-foreground))]">
              {lang === 'fa' ? 'هنوز فاکتوری ندارید' : 'No invoices yet'}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
