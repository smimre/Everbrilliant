'use client';
import { useLocaleStore } from '@/store/locale.store';
export function TreasuryPage() {
  const { lang } = useLocaleStore();
  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold">🏦 {lang === 'fa' ? 'خزانه' : 'Treasury'}</h1>
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-5 grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[{icon:'💳',label_fa:'حساب‌های بانکی',label_en:'Bank Accounts'},{icon:'📑',label_fa:'چک‌ها',label_en:'Checks'},{icon:'💱',label_fa:'تراکنش‌ها',label_en:'Transactions'}].map(i=>(
          <button key={i.icon} className="flex flex-col items-center gap-3 p-6 rounded-xl border border-[hsl(var(--border))] hover:bg-[hsl(var(--muted)/0.4)] transition-colors">
            <span className="text-4xl">{i.icon}</span>
            <span className="font-semibold">{lang==='fa'?i.label_fa:i.label_en}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
