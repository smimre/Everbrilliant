'use client';
import { FinanceModule } from '@/modules/finance';
export default function InventoryPage() {
  return <FinanceModule initialPage="inventory" />;
}
