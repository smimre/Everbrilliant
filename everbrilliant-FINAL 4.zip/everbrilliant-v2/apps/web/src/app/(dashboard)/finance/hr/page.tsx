'use client';
import { FinanceModule } from '@/modules/finance';
export default function HRPage() {
  return <FinanceModule initialPage="hr" />;
}
