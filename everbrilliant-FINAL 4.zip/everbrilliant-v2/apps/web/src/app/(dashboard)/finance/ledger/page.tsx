'use client';
import { FinanceModule } from '@/modules/finance';
export default function LedgerPage() {
  return <FinanceModule initialPage="accounting" />;
}
