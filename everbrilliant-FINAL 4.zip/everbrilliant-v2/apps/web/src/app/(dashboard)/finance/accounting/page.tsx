'use client';
import { FinanceModule } from '@/modules/finance';
export default function AccountingPage() {
  return <FinanceModule initialPage="accounting" />;
}
