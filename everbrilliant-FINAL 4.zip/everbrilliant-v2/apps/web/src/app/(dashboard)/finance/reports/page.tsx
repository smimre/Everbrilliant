'use client';
import { FinanceModule } from '@/modules/finance';
export default function FinanceReportsPage() {
  return <FinanceModule initialPage="reports" />;
}
