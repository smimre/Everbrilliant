'use client';
import { FinanceModule } from '@/modules/finance';
export default function InvoicesPage() {
  return <FinanceModule initialPage="invoices" />;
}
