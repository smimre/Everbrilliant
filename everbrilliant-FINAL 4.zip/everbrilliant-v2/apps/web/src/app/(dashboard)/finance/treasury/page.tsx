'use client';
import { FinanceModule } from '@/modules/finance';
export default function TreasuryPage() {
  return <FinanceModule initialPage="treasury" />;
}
