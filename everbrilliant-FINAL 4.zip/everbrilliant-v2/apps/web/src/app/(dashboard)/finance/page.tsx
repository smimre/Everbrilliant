'use client';
import { FinanceModule } from '@/modules/finance';
export default function FinancePage() {
  return <FinanceModule />;
}
