'use client';
import { FinanceModule } from '@/modules/finance';
export default function JournalPage() {
  return <FinanceModule initialPage="accounting" />;
}
