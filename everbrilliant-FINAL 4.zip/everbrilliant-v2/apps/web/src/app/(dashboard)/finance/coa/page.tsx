'use client';
import { FinanceModule } from '@/modules/finance';
export default function COAPage() {
  return <FinanceModule initialPage="accounting" />;
}
