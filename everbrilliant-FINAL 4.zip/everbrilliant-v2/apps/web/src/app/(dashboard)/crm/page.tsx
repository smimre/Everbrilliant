'use client';
import { CRMModule } from '@/modules/crm';
export default function CRMPage() {
  return <CRMModule />;
}
