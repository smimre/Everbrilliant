'use client';
import { AutomationModule } from '@/modules/automation';
export default function MeetingsPage() {
  return <AutomationModule initialView="meetings" />;
}
