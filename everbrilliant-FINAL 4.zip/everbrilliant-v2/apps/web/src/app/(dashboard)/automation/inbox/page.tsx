'use client';
import { AutomationModule } from '@/modules/automation';
export default function AutoInboxPage() {
  return <AutomationModule initialView="letters" />;
}
