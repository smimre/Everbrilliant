'use client';
import { AutomationModule } from '@/modules/automation';
export default function TasksPage() {
  return <AutomationModule initialView="tasks" />;
}
