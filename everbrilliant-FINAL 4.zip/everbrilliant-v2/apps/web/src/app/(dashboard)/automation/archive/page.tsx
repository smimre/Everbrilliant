'use client';
import { AutomationModule } from '@/modules/automation';
export default function ArchivePage() {
  return <AutomationModule initialView="archive" />;
}
