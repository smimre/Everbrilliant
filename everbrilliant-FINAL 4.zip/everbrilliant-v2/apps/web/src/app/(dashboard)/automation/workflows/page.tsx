'use client';
import { AutomationModule } from '@/modules/automation';
export default function WorkflowsPage() {
  return <AutomationModule initialView="workflows" />;
}
