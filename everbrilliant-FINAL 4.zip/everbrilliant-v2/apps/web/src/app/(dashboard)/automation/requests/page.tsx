'use client';
import { AutomationModule } from '@/modules/automation';
export default function AutoRequestsPage() {
  return <AutomationModule initialView="requests" />;
}
