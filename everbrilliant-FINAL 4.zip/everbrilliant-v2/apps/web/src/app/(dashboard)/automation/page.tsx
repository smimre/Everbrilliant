'use client';
import { AutomationModule } from '@/modules/automation';
export default function AutomationPage() {
  return <AutomationModule />;
}
