'use client';
import { AutomationModule } from '@/modules/automation';
export default function AutoOutboxPage() {
  return <AutomationModule initialView="letters" />;
}
