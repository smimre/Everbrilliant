'use client';
import { TradingModule } from '@/modules/trading';
export default function InboxPage() {
  return <TradingModule initialView="dashboard" />;
}
