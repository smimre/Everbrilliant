'use client';
import { TradingModule } from '@/modules/trading';
export default function TradingPage() {
  return <TradingModule />;
}
