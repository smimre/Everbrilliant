'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { useAuthStore } from '@/store/auth.store';
import { useUIStore } from '@/store/ui.store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Settings, User, Bell, Palette, Shield, Globe } from 'lucide-react';
import { cn } from '@/lib/utils';

type SettingsTab = 'profile' | 'appearance' | 'notifications' | 'security' | 'language';

export default function SettingsPage() {
  const { lang, setLocale } = useLocaleStore();
  const { user } = useAuthStore();
  const { theme } = useUIStore();
  const [tab, setTab] = useState<SettingsTab>('profile');

  const tabs = [
    { id: 'profile',       icon: <User className="h-4 w-4"/>,     label_fa: 'پروفایل',   label_en: 'Profile' },
    { id: 'appearance',    icon: <Palette className="h-4 w-4"/>,  label_fa: 'ظاهر',      label_en: 'Appearance' },
    { id: 'notifications', icon: <Bell className="h-4 w-4"/>,     label_fa: 'اعلان‌ها',  label_en: 'Notifications' },
    { id: 'security',      icon: <Shield className="h-4 w-4"/>,   label_fa: 'امنیت',     label_en: 'Security' },
    { id: 'language',      icon: <Globe className="h-4 w-4"/>,    label_fa: 'زبان',      label_en: 'Language' },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold flex items-center gap-2">
        <Settings className="h-6 w-6 text-[hsl(var(--primary))]"/>
        {lang === 'fa' ? 'تنظیمات' : 'Settings'}
      </h1>

      <div className="flex gap-6">
        {/* Sidebar */}
        <div className="w-48 shrink-0 space-y-1">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id as SettingsTab)}
              className={cn(
                'w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-all',
                tab === t.id
                  ? 'bg-[hsl(var(--primary)/0.12)] text-[hsl(var(--primary))]'
                  : 'text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted)/0.5)]'
              )}>
              {t.icon}
              {lang === 'fa' ? t.label_fa : t.label_en}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-6">
          {tab === 'profile' && (
            <div className="space-y-4">
              <h2 className="font-semibold text-lg">{lang === 'fa' ? 'اطلاعات پروفایل' : 'Profile Info'}</h2>
              <Input label={lang === 'fa' ? 'نام' : 'Name'} defaultValue={user?.name} />
              <Input label={lang === 'fa' ? 'شماره موبایل' : 'Phone'} defaultValue={user?.phone} disabled />
              <Button>{lang === 'fa' ? 'ذخیره' : 'Save'}</Button>
            </div>
          )}

          {tab === 'language' && (
            <div className="space-y-4">
              <h2 className="font-semibold text-lg">{lang === 'fa' ? 'تنظیمات زبان' : 'Language Settings'}</h2>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { code: 'fa', label: 'فارسی', flag: '🇮🇷' },
                  { code: 'en', label: 'English', flag: '🇬🇧' },
                  { code: 'ar', label: 'العربية', flag: '🇸🇦' },
                  { code: 'hi', label: 'हिन्दी', flag: '🇮🇳' },
                ].map(l => (
                  <button key={l.code} onClick={() => setLocale(l.code as any)}
                    className={cn(
                      'flex items-center gap-3 p-4 rounded-xl border transition-all',
                      lang === l.code
                        ? 'border-[hsl(var(--primary))] bg-[hsl(var(--primary)/0.08)]'
                        : 'border-[hsl(var(--border))] hover:border-[hsl(var(--primary)/0.3)]'
                    )}>
                    <span className="text-2xl">{l.flag}</span>
                    <span className="font-medium">{l.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {tab === 'appearance' && (
            <div className="space-y-4">
              <h2 className="font-semibold text-lg">{lang === 'fa' ? 'تنظیمات ظاهری' : 'Appearance'}</h2>
              <div className="grid grid-cols-2 gap-3">
                {['light', 'dark'].map(t => (
                  <button key={t}
                    className={cn(
                      'p-6 rounded-xl border transition-all text-center',
                      theme === t
                        ? 'border-[hsl(var(--primary))] bg-[hsl(var(--primary)/0.08)]'
                        : 'border-[hsl(var(--border))] hover:border-[hsl(var(--primary)/0.3)]'
                    )}>
                    <p className="text-3xl mb-2">{t === 'dark' ? '🌙' : '☀️'}</p>
                    <p className="font-medium">{t === 'dark' ? (lang === 'fa' ? 'تیره' : 'Dark') : (lang === 'fa' ? 'روشن' : 'Light')}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {tab === 'notifications' && (
            <div className="space-y-4">
              <h2 className="font-semibold text-lg">{lang === 'fa' ? 'تنظیمات اعلان‌ها' : 'Notification Settings'}</h2>
              <p className="text-[hsl(var(--muted-foreground))]">{lang === 'fa' ? 'به زودی...' : 'Coming soon...'}</p>
            </div>
          )}

          {tab === 'security' && (
            <div className="space-y-4">
              <h2 className="font-semibold text-lg">{lang === 'fa' ? 'تنظیمات امنیتی' : 'Security Settings'}</h2>
              <Input label={lang === 'fa' ? 'رمز عبور فعلی' : 'Current Password'} type="password" />
              <Input label={lang === 'fa' ? 'رمز عبور جدید' : 'New Password'} type="password" />
              <Input label={lang === 'fa' ? 'تکرار رمز عبور' : 'Confirm Password'} type="password" />
              <Button>{lang === 'fa' ? 'تغییر رمز' : 'Change Password'}</Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
