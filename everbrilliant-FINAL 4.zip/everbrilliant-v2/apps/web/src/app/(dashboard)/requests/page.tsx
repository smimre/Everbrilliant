'use client';
import { TradingModule } from '@/modules/trading';
export default function RequestsPage() {
  return <TradingModule initialView="requests" />;
}
