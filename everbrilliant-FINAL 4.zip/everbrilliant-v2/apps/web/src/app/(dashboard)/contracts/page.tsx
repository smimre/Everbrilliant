'use client';
import { TradingModule } from '@/modules/trading';
export default function ContractsPage() {
  return <TradingModule initialView="contracts" />;
}
