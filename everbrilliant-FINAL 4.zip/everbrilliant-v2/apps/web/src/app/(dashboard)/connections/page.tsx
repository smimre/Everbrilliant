'use client';
import { TradingModule } from '@/modules/trading';
export default function ConnectionsPage() {
  return <TradingModule initialView="connections" />;
}
