'use client';
import { TradingModule } from '@/modules/trading';
export default function TendersPage() {
  return <TradingModule initialView="tenders" />;
}
