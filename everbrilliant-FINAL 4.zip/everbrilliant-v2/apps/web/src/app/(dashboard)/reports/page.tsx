'use client';
import { useLocaleStore } from '@/store/locale.store';
import { StatCard } from '@/components/dashboard/stat-card';
import { BarChart3 } from 'lucide-react';
export default function ReportsPage() {
  const { lang } = useLocaleStore();
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold flex items-center gap-2">
        <BarChart3 className="h-6 w-6 text-[hsl(var(--primary))]" />
        {lang === 'fa' ? 'گزارشات' : 'Reports'}
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-8 text-center">
          <p className="text-4xl mb-3">📊</p>
          <p className="font-semibold">{lang === 'fa' ? 'گزارشات بازرگانی' : 'Trading Reports'}</p>
          <p className="text-sm text-[hsl(var(--muted-foreground))] mt-1">{lang === 'fa' ? 'به زودی' : 'Coming soon'}</p>
        </div>
        <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-8 text-center">
          <p className="text-4xl mb-3">💰</p>
          <p className="font-semibold">{lang === 'fa' ? 'گزارشات مالی' : 'Finance Reports'}</p>
          <p className="text-sm text-[hsl(var(--muted-foreground))] mt-1">{lang === 'fa' ? 'به زودی' : 'Coming soon'}</p>
        </div>
      </div>
    </div>
  );
}
