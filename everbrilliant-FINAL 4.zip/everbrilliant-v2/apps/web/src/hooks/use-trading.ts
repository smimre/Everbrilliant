import { useQuery, useMutation, useQueryClient, keepPreviousData } from '@tanstack/react-query';
import { tradingService } from '@/services';
import { useUIStore } from '@/store';
import type { PaginationQuery } from '@/types';

// ── Query Keys ─────────────────────────────────
export const tradingKeys = {
  all: ['trading'] as const,
  requests: (query?: PaginationQuery & { status?: string }) =>
    [...tradingKeys.all, 'requests', query] as const,
  request: (id: string) => [...tradingKeys.all, 'request', id] as const,
  contracts: (query?: PaginationQuery) => [...tradingKeys.all, 'contracts', query] as const,
  contract: (id: string) => [...tradingKeys.all, 'contract', id] as const,
  tenders: (query?: PaginationQuery) => [...tradingKeys.all, 'tenders', query] as const,
};

// ── Requests ───────────────────────────────────
export function useRequests(query?: PaginationQuery & { status?: string }) {
  return useQuery({
    queryKey: tradingKeys.requests(query),
    queryFn: () => tradingService.getRequests(query),
    placeholderData: keepPreviousData,
    staleTime: 30_000,
  });
}

export function useRequest(id: string) {
  return useQuery({
    queryKey: tradingKeys.request(id),
    queryFn: () => tradingService.getRequest(id),
    enabled: !!id,
    staleTime: 30_000,
  });
}

export function useCreateRequest() {
  const qc = useQueryClient();
  const { toast } = useUIStore();
  return useMutation({
    mutationFn: tradingService.createRequest,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: tradingKeys.all });
      toast('success', 'Request created successfully');
    },
    onError: (err: Error) => toast('error', err.message),
  });
}

export function useCancelRequest() {
  const qc = useQueryClient();
  const { toast } = useUIStore();
  return useMutation({
    mutationFn: tradingService.cancelRequest,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: tradingKeys.all });
      toast('success', 'Request cancelled');
    },
    onError: (err: Error) => toast('error', err.message),
  });
}

// ── Contracts ─────────────────────────────────
export function useContracts(query?: PaginationQuery) {
  return useQuery({
    queryKey: tradingKeys.contracts(query),
    queryFn: () => tradingService.getContracts(query),
    placeholderData: keepPreviousData,
    staleTime: 60_000,
  });
}

export function useSignContract() {
  const qc = useQueryClient();
  const { toast } = useUIStore();
  return useMutation({
    mutationFn: tradingService.signContract,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: tradingKeys.all });
      toast('success', 'Contract signed successfully');
    },
    onError: (err: Error) => toast('error', err.message),
  });
}

// ── Tenders ───────────────────────────────────
export function useTenders(query?: PaginationQuery) {
  return useQuery({
    queryKey: tradingKeys.tenders(query),
    queryFn: () => tradingService.getTenders(query),
    placeholderData: keepPreviousData,
    staleTime: 30_000,
  });
}

export function usePlaceBid() {
  const qc = useQueryClient();
  const { toast } = useUIStore();
  return useMutation({
    mutationFn: ({ tenderId, dto }: { tenderId: string; dto: Parameters<typeof tradingService.placeBid>[1] }) =>
      tradingService.placeBid(tenderId, dto),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: tradingKeys.all });
      toast('success', 'Bid placed successfully');
    },
    onError: (err: Error) => toast('error', err.message),
  });
}
