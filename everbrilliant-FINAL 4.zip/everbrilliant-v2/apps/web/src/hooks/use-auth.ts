import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import { authService } from '@/services';
import { useAuthStore } from '@/store/auth.store';
import { useCompanyStore } from '@/store/company.store';
import { useNotificationStore } from '@/store/notification.store';
import { useUIStore } from '@/store/ui.store';
import type { LoginDto, RegisterDto } from '@/types';

export function useLogin() {
  const { setAuth } = useAuthStore();
  const { toast } = useUIStore();
  const router = useRouter();

  return useMutation({
    mutationFn: (dto: LoginDto) => authService.login(dto),
    onSuccess: (data) => {
      setAuth(data.user, data.accessToken, data.refreshToken);
      router.replace('/dashboard');
    },
    onError: (err: Error) => toast('error', err.message),
  });
}

export function useRegister() {
  const { setAuth } = useAuthStore();
  const { toast } = useUIStore();
  const router = useRouter();

  return useMutation({
    mutationFn: (dto: RegisterDto) => authService.register(dto),
    onSuccess: (data) => {
      setAuth(
        { ...(data.user as any), role: 'company_admin', permissions: [], companyId: 0, isCompanyAdmin: true },
        data.accessToken,
        data.refreshToken
      );
      router.replace('/dashboard');
    },
    onError: (err: Error) => toast('error', err.message),
  });
}

export function useLogout() {
  const { clearAuth } = useAuthStore();
  const { reset: resetCompany } = useCompanyStore();
  const { reset: resetNotif } = useNotificationStore();
  const qc = useQueryClient();
  const router = useRouter();

  return useMutation({
    mutationFn: () => authService.logout().catch(() => {}),
    onSettled: () => {
      clearAuth();
      resetCompany();
      resetNotif();
      qc.clear();
      router.replace('/login');
    },
  });
}

export function useAuth() {
  const store = useAuthStore();
  const { mutate: logoutMutate, isPending: isLoggingOut } = useLogout();
  return { ...store, logout: logoutMutate, isLoggingOut };
}
