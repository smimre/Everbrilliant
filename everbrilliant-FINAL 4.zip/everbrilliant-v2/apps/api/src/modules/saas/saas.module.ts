import { Module } from '@nestjs/common';
import { PlansService } from './plans/plans.service';
import { BillingService } from './billing/billing.service';
import { BillingController } from './billing/billing.controller';
import { UsageService } from './usage/usage.service';
import { UsageController } from './usage/usage.controller';
import { UsageLimitGuard } from './usage/usage.guard';
import { WhiteLabelService } from './white-label/white-label.service';
import { WhiteLabelController } from './white-label/white-label.controller';

@Module({
  controllers: [BillingController, UsageController, WhiteLabelController],
  providers: [PlansService, BillingService, UsageService, UsageLimitGuard, WhiteLabelService],
  exports: [PlansService, BillingService, UsageService, UsageLimitGuard, WhiteLabelService],
})
export class SaasModule {}
