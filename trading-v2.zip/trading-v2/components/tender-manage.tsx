'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { useTenders, useCreateTender } from '@/hooks/use-trading';

interface Props { showNew?: boolean; }

export function TenderManage({ showNew: initShowNew }: Props = {}) {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const { data: tenders = [], isLoading } = useTenders();
  const [showNew, setShowNew] = useState(initShowNew || false);
  const [selected, setSelected] = useState<any>(null);
  const mine = (tenders as any[]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">🏆 {fa ? 'مزایده‌های من' : 'My Auctions'}</h1>
          <p className="text-sm text-[hsl(var(--muted-foreground))]">{mine.length} {fa ? 'مزایده' : 'auctions'}</p>
        </div>
        <button onClick={() => setShowNew(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium">
          ➕ {fa ? 'مزایده جدید' : 'New Auction'}
        </button>
      </div>

      {isLoading ? (
        <div className="space-y-3">{[1,2].map(i => <div key={i} className="h-28 rounded-xl bg-[hsl(var(--muted)/0.5)] animate-pulse" />)}</div>
      ) : mine.length === 0 ? (
        <div className="text-center py-16 text-[hsl(var(--muted-foreground))]">
          <div className="text-4xl mb-3">🏷️</div>
          <p className="font-medium">{fa ? 'مزایده‌ای ایجاد نشده' : 'No auctions yet'}</p>
          <button onClick={() => setShowNew(true)} className="mt-4 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm">
            {fa ? '➕ مزایده جدید' : '➕ New Auction'}
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {mine.map((t: any) => {
            const statusColor = t.status === 'open' ? '#10b981' : t.status === 'closed' ? '#64748b' : '#f59e0b';
            const statusLabel = t.status === 'open' ? (fa ? 'باز' : 'Open') : t.status === 'closed' ? (fa ? 'بسته' : 'Closed') : (fa ? 'برنده اعلام شد' : 'Awarded');
            return (
              <div key={t.id} onClick={() => setSelected(t)}
                className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4 cursor-pointer hover:border-[hsl(var(--primary)/0.3)] transition-colors">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-sm">{t.title}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: statusColor + '20', color: statusColor }}>
                        {statusLabel}
                      </span>
                    </div>
                    <div className="flex gap-4 text-xs text-[hsl(var(--muted-foreground))]">
                      {t.deadline && <span>📅 {t.deadline}</span>}
                      <span>🏆 {(t.bids || []).length} {fa ? 'پیشنهاد' : 'bids'}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {t.status === 'open' && (
                      <button className="text-xs px-3 py-1.5 rounded-lg border border-[hsl(var(--border))] hover:bg-[hsl(var(--muted)/0.5)]">
                        {fa ? 'بستن' : 'Close'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showNew && <NewTenderModal lang={lang} onClose={() => setShowNew(false)} />}
    </div>
  );
}

function NewTenderModal({ lang, onClose }: { lang: string; onClose: () => void }) {
  const fa = lang === 'fa';
  const [form, setForm] = useState({ title: '', deadline: '', deadlineTime: '23:59', description: '', isPublic: true });
  const inp = "w-full px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)]";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-[hsl(var(--secondary))] rounded-2xl border border-[hsl(var(--border))] w-full max-w-md p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-bold text-lg">🏷️ {fa ? 'مزایده جدید' : 'New Auction'}</h2>
          <button onClick={onClose} className="text-xl text-[hsl(var(--muted-foreground))]">✕</button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">{fa ? 'عنوان مزایده *' : 'Auction Title *'}</label>
            <input value={form.title} onChange={e => setForm({...form, title: e.target.value})} className={inp} placeholder={fa ? 'مثال: خرید روغن موتور ۱۰۰۰ لیتر' : 'e.g. Motor Oil Purchase 1000L'} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">📅 {fa ? 'تاریخ مهلت' : 'Deadline Date'}</label>
              <input value={form.deadline} onChange={e => setForm({...form, deadline: e.target.value})} className={inp} placeholder="1403/06/15" />
            </div>
            <div>
              <label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">⏰ {fa ? 'ساعت مهلت' : 'Deadline Time'}</label>
              <input value={form.deadlineTime} onChange={e => setForm({...form, deadlineTime: e.target.value})} className={inp} type="time" />
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">{fa ? 'توضیحات' : 'Description'}</label>
            <textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} rows={3} className={inp + " resize-none"} />
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={form.isPublic} onChange={e => setForm({...form, isPublic: e.target.checked})} className="w-4 h-4" />
            <span className="text-sm">{fa ? 'مزایده عمومی (همه می‌توانند شرکت کنند)' : 'Public auction (anyone can participate)'}</span>
          </label>
        </div>
        <div className="flex gap-3 mt-5">
          <button onClick={onClose} className="flex-1 px-4 py-2 rounded-lg border border-[hsl(var(--border))] text-sm">{fa ? 'انصراف' : 'Cancel'}</button>
          <button className="flex-1 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium">🏷️ {fa ? 'ایجاد مزایده' : 'Create Auction'}</button>
        </div>
      </div>
    </div>
  );
}
