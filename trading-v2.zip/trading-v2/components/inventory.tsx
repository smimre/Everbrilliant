'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';

export function InventoryPage() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const [showNew, setShowNew] = useState(false);
  const [items] = useState<any[]>([]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">📦 {fa ? 'موجودی کالا' : 'Inventory'}</h1>
          <p className="text-sm text-[hsl(var(--muted-foreground))]">{items.length} {fa ? 'قلم کالا' : 'items'}</p>
        </div>
        <button onClick={() => setShowNew(true)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium">
          ➕ {fa ? 'کالای جدید' : 'New Item'}
        </button>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { icon: '📦', val: items.length, label: fa ? 'اقلام انبار من' : 'My Inventory', color: '#3b82f6' },
          { icon: '⚠️', val: 0, label: fa ? 'موجودی کم' : 'Low Stock', color: '#ef4444' },
          { icon: '💰', val: '0', label: fa ? 'ارزش کل' : 'Total Value', color: '#10b981' },
          { icon: '👁️', val: 0, label: fa ? 'قابل مشاهده' : 'Visible to Partners', color: '#8b5cf6' },
        ].map((s, i) => (
          <div key={i} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-3 text-center">
            <div className="text-xl mb-1">{s.icon}</div>
            <div className="text-xl font-bold" style={{ color: s.color }}>{s.val}</div>
            <div className="text-xs text-[hsl(var(--muted-foreground))]">{s.label}</div>
          </div>
        ))}
      </div>

      {items.length === 0 ? (
        <div className="text-center py-16 text-[hsl(var(--muted-foreground))]">
          <div className="text-4xl mb-3">📦</div>
          <p className="font-medium">{fa ? 'انبار خالی است' : 'Inventory is empty'}</p>
          <button onClick={() => setShowNew(true)} className="mt-4 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm">
            {fa ? '+ افزودن کالا' : '+ Add Item'}
          </button>
        </div>
      ) : (
        <div className="rounded-xl border border-[hsl(var(--border))] overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-[hsl(var(--muted)/0.5)]">
              <tr>
                {[fa?'نام کالا':'Item', fa?'کد':'Code', fa?'موجودی':'Stock', fa?'واحد':'Unit', fa?'قیمت واحد':'Unit Cost', fa?'وضعیت':'Status'].map(h => (
                  <th key={h} className="text-start px-4 py-3 text-xs font-semibold text-[hsl(var(--muted-foreground))]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {items.map((item: any) => (
                <tr key={item.id} className="border-t border-[hsl(var(--border))] hover:bg-[hsl(var(--muted)/0.3)]">
                  <td className="px-4 py-3 font-medium">{item.name}</td>
                  <td className="px-4 py-3 text-[hsl(var(--muted-foreground))]">{item.code}</td>
                  <td className="px-4 py-3">{item.qty}</td>
                  <td className="px-4 py-3 text-[hsl(var(--muted-foreground))]">{item.unit}</td>
                  <td className="px-4 py-3">{Number(item.unitCost).toLocaleString('fa-IR')}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${item.qty <= item.minQty ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                      {item.qty <= item.minQty ? (fa ? 'کم' : 'Low') : (fa ? 'کافی' : 'OK')}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showNew && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-[hsl(var(--secondary))] rounded-2xl border border-[hsl(var(--border))] w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-bold text-lg">📦 {fa ? 'کالای جدید' : 'New Item'}</h2>
              <button onClick={() => setShowNew(false)} className="text-xl text-[hsl(var(--muted-foreground))]">✕</button>
            </div>
            <div className="space-y-3">
              {[
                { label: fa?'نام کالا *':'Item Name *', id: 'name', type: 'text' },
                { label: fa?'کد کالا':'Item Code', id: 'code', type: 'text' },
                { label: fa?'موجودی فعلی':'Current Stock', id: 'qty', type: 'number' },
                { label: fa?'حداقل موجودی':'Min Stock', id: 'minQty', type: 'number' },
                { label: fa?'قیمت واحد (ریال)':'Unit Cost (IRR)', id: 'cost', type: 'number' },
              ].map(f => (
                <div key={f.id}>
                  <label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">{f.label}</label>
                  <input type={f.type} className="w-full px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)]" />
                </div>
              ))}
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setShowNew(false)} className="flex-1 px-4 py-2 rounded-lg border border-[hsl(var(--border))] text-sm">{fa?'انصراف':'Cancel'}</button>
              <button className="flex-1 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium">✅ {fa?'ذخیره':'Save'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
