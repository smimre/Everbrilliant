'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { useConnections } from '@/hooks/use-trading';

export function Connections() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const { data: connections = [], isLoading } = useConnections();
  const [tab, setTab] = useState<'all'|'invite'>('all');
  const [code, setCode] = useState('');

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold">🔗 {fa ? 'اتصالات تجاری' : 'Business Connections'}</h1>
        <p className="text-sm text-[hsl(var(--muted-foreground))]">{(connections as any[]).length} {fa ? 'شریک تجاری' : 'partners'}</p>
      </div>

      <div className="flex gap-1 border-b border-[hsl(var(--border))]">
        {[
          { id: 'all', label: fa ? 'شرکای من' : 'My Partners', icon: '👥' },
          { id: 'invite', label: fa ? 'دعوت همکار' : 'Invite Partner', icon: '🔗' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id as any)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === t.id ? 'border-[hsl(var(--primary))] text-[hsl(var(--primary))]' : 'border-transparent text-[hsl(var(--muted-foreground))]'}`}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {tab === 'all' && (
        isLoading ? (
          <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-16 rounded-xl bg-[hsl(var(--muted)/0.5)] animate-pulse" />)}</div>
        ) : (connections as any[]).length === 0 ? (
          <div className="text-center py-16 text-[hsl(var(--muted-foreground))]">
            <div className="text-4xl mb-3">🔌</div>
            <p className="font-medium">{fa ? 'اتصالی ثبت نشده' : 'No connections yet'}</p>
            <button onClick={() => setTab('invite')} className="mt-4 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm">
              🔗 {fa ? 'دعوت همکار' : 'Invite Partner'}
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {(connections as any[]).map((c: any) => (
              <div key={c.id} className="flex items-center gap-3 p-3 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] hover:border-[hsl(var(--primary)/0.3)] transition-colors">
                <div className="w-10 h-10 rounded-full bg-[hsl(var(--primary)/0.1)] flex items-center justify-center text-lg">
                  {c.name?.[0] || '🏢'}
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium">{c.name}</div>
                  <div className="text-xs text-[hsl(var(--muted-foreground))]">{c.type || (fa ? 'شریک تجاری' : 'Business Partner')}</div>
                </div>
                <button className="text-xs px-3 py-1.5 rounded-lg border border-[hsl(var(--border))] hover:bg-[hsl(var(--muted)/0.5)]">
                  {fa ? 'پروفایل' : 'Profile'}
                </button>
              </div>
            ))}
          </div>
        )
      )}

      {tab === 'invite' && (
        <div className="space-y-4">
          {/* Generate Code */}
          <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4">
            <h3 className="font-semibold mb-3">🔑 {fa ? 'کد دعوت من' : 'My Invite Code'}</h3>
            <p className="text-sm text-[hsl(var(--muted-foreground))] mb-3">
              {fa ? 'این کد را به شریک تجاری خود بدهید تا به شبکه شما متصل شود.' : 'Share this code with your partner to connect.'}
            </p>
            <div className="flex gap-2">
              <div className="flex-1 px-4 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm font-mono text-center tracking-wider">
                {fa ? 'کد در حال تولید...' : 'Code generating...'}
              </div>
              <button className="px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm">
                {fa ? 'کپی' : 'Copy'}
              </button>
            </div>
          </div>

          {/* Enter Code */}
          <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4">
            <h3 className="font-semibold mb-3">🔗 {fa ? 'وارد کردن کد دعوت' : 'Enter Invite Code'}</h3>
            <div className="flex gap-2">
              <input value={code} onChange={e => setCode(e.target.value)}
                placeholder={fa ? 'کد دعوت شریک تجاری...' : 'Partner invite code...'}
                className="flex-1 px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)]" />
              <button className="px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium">
                {fa ? 'اتصال' : 'Connect'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
