'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { useRequests } from '@/hooks/use-trading';

export function CRMPage() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const { data: requests = [] } = useRequests();
  const [tab, setTab] = useState<'pipeline'|'followups'|'partners'>('pipeline');

  const open = (requests as any[]).filter((r) => !['completed','rejected','cancelled'].includes(r.status));
  const won = (requests as any[]).filter((r) => r.status === 'completed' || r.status === 'paid');
  const convRate = (requests as any[]).length ? Math.round(won.length / (requests as any[]).length * 100) : 0;
  const pipeline = open.reduce((s: number, r: any) => s + (r.amountIRR || 0), 0);

  const tabs = [
    { id: 'pipeline', label: fa ? 'پایپ‌لاین' : 'Pipeline', icon: '📊' },
    { id: 'followups', label: fa ? 'پیگیری‌ها' : 'Follow-ups', icon: '🔔' },
    { id: 'partners', label: fa ? 'شرکا' : 'Partners', icon: '🤝' },
  ];

  const stages = [
    { key: 'pending', label: fa ? 'در انتظار' : 'Pending', color: '#f59e0b' },
    { key: 'quoted', label: fa ? 'قیمت داده' : 'Quoted', color: '#3b82f6' },
    { key: 'approved', label: fa ? 'تایید شده' : 'Approved', color: '#8b5cf6' },
    { key: 'paid', label: fa ? 'پرداخت شده' : 'Paid', color: '#06b6d4' },
    { key: 'completed', label: fa ? 'تکمیل شده' : 'Completed', color: '#10b981' },
  ];

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold">🎯 {fa ? 'مدیریت مشتریان' : 'CRM'}</h1>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-5 gap-3">
        {[
          { icon: '⚠️', val: 0, label: fa ? 'پیگیری عقب‌افتاده' : 'Overdue Follow-ups', color: '#ef4444' },
          { icon: '📅', val: 0, label: fa ? 'پیگیری امروز' : "Today's Follow-ups", color: '#f59e0b' },
          { icon: '📋', val: open.length, label: fa ? 'فرصت‌های باز' : 'Open Deals', color: '#3b82f6' },
          { icon: '📈', val: convRate + '%', label: fa ? 'نرخ تبدیل' : 'Conversion Rate', color: '#10b981' },
          { icon: '💰', val: pipeline > 0 ? (pipeline / 1000000).toFixed(0) + 'M' : '0', label: fa ? 'ارزش پایپ‌لاین' : 'Pipeline Value', color: '#8b5cf6' },
        ].map((s, i) => (
          <div key={i} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-3 text-center">
            <div className="text-lg mb-1">{s.icon}</div>
            <div className="text-lg font-bold" style={{ color: s.color }}>{s.val}</div>
            <div className="text-[10px] text-[hsl(var(--muted-foreground))] leading-tight">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-[hsl(var(--border))]">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id as any)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === t.id ? 'border-[hsl(var(--primary))] text-[hsl(var(--primary))]' : 'border-transparent text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]'}`}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {tab === 'pipeline' && (
        <div className="space-y-4">
          {stages.map(stage => {
            const items = (requests as any[]).filter((r: any) => r.status === stage.key);
            if (!items.length) return null;
            return (
              <div key={stage.key}>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-3 h-3 rounded-full" style={{ background: stage.color }} />
                  <span className="text-sm font-medium">{stage.label}</span>
                  <span className="text-xs text-[hsl(var(--muted-foreground))]">({items.length})</span>
                </div>
                <div className="space-y-2 ps-5">
                  {items.map((r: any) => (
                    <div key={r.id} className="rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-3">
                      <div className="text-sm font-medium">{r.productName || r.title}</div>
                      {r.amountIRR && <div className="text-xs text-[hsl(var(--muted-foreground))] mt-1">💰 {Number(r.amountIRR).toLocaleString('fa-IR')} ریال</div>}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
          {open.length === 0 && (
            <div className="text-center py-8 text-[hsl(var(--muted-foreground))]">
              <div className="text-3xl mb-2">🎯</div>
              <p className="text-sm">{fa ? 'فرصت تجاری‌ای در پایپ‌لاین نیست' : 'No deals in pipeline'}</p>
            </div>
          )}
        </div>
      )}

      {tab === 'followups' && (
        <div className="text-center py-16 text-[hsl(var(--muted-foreground))]">
          <div className="text-4xl mb-3">🔔</div>
          <p className="font-medium">{fa ? 'هیچ پیگیری‌ای برنامه‌ریزی نشده' : 'No follow-ups scheduled'}</p>
          <button className="mt-4 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm">
            {fa ? '+ پیگیری جدید' : '+ New Follow-up'}
          </button>
        </div>
      )}

      {tab === 'partners' && (
        <div className="text-center py-16 text-[hsl(var(--muted-foreground))]">
          <div className="text-4xl mb-3">🤝</div>
          <p className="font-medium">{fa ? 'هنوز شریکی ثبت نشده' : 'No partners yet'}</p>
        </div>
      )}
    </div>
  );
}
