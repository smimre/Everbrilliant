'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { useTenders } from '@/hooks/use-trading';

export function TenderBrowse() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const { data: tenders = [], isLoading } = useTenders();
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<any>(null);

  const open = (tenders as any[]).filter((t) => t.status === 'open');
  const filtered = open.filter((t: any) =>
    !search || (t.title || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold">🏷️ {fa ? 'مزایده‌های فعال' : 'Active Auctions'}</h1>
        <p className="text-sm text-[hsl(var(--muted-foreground))]">{open.length} {fa ? 'مزایده باز' : 'open auctions'}</p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {[
          { icon: '🏷️', val: open.length, label: fa ? 'مزایده فعال' : 'Active Auctions', color: '#3b82f6' },
          { icon: '✅', val: (tenders as any[]).filter((t: any) => t.status === 'closed').length, label: fa ? 'بسته شده' : 'Closed', color: '#10b981' },
          { icon: '🏆', val: (tenders as any[]).filter((t: any) => t.status === 'awarded').length, label: fa ? 'برنده اعلام شده' : 'Awarded', color: '#f59e0b' },
        ].map((s, i) => (
          <div key={i} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-3 text-center">
            <div className="text-xl mb-1">{s.icon}</div>
            <div className="text-xl font-bold" style={{ color: s.color }}>{s.val}</div>
            <div className="text-xs text-[hsl(var(--muted-foreground))]">{s.label}</div>
          </div>
        ))}
      </div>

      <input value={search} onChange={e => setSearch(e.target.value)}
        placeholder={fa ? 'جستجو در مزایده‌ها...' : 'Search auctions...'}
        className="w-full px-4 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)]" />

      {isLoading ? (
        <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-28 rounded-xl bg-[hsl(var(--muted)/0.5)] animate-pulse" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-[hsl(var(--muted-foreground))]">
          <div className="text-4xl mb-3">🏷️</div>
          <p className="font-medium">{fa ? 'مزایده‌ای یافت نشد' : 'No auctions found'}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((t: any) => (
            <div key={t.id} onClick={() => setSelected(t)}
              className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4 cursor-pointer hover:border-[hsl(var(--primary)/0.3)] transition-colors">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-sm mb-1">{t.title}</div>
                  <div className="flex flex-wrap gap-3 text-xs text-[hsl(var(--muted-foreground))]">
                    {t.deadline && <span>📅 {fa ? 'مهلت:' : 'Deadline:'} {t.deadline}</span>}
                    {t.products?.length && <span>📦 {t.products.length} {fa ? 'قلم' : 'items'}</span>}
                    {t.bids?.length && <span>🏆 {t.bids.length} {fa ? 'پیشنهاد' : 'bids'}</span>}
                  </div>
                </div>
                <button className="px-3 py-1.5 rounded-lg bg-[hsl(var(--primary))] text-white text-xs font-medium shrink-0">
                  {fa ? 'شرکت در مزایده' : 'Place Bid'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-[hsl(var(--secondary))] rounded-2xl border border-[hsl(var(--border))] w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold">🏷️ {selected.title}</h2>
              <button onClick={() => setSelected(null)} className="text-xl text-[hsl(var(--muted-foreground))]">✕</button>
            </div>
            <div className="space-y-3 text-sm">
              {selected.deadline && <div className="flex justify-between py-2 border-b border-[hsl(var(--border)/0.5)]"><span className="text-[hsl(var(--muted-foreground))]">{fa ? 'مهلت' : 'Deadline'}</span><span>{selected.deadline}</span></div>}
              {selected.description && <p className="text-[hsl(var(--muted-foreground))]">{selected.description}</p>}
            </div>
            <div className="mt-4 space-y-2">
              <label className="text-xs font-medium text-[hsl(var(--muted-foreground))]">{fa ? 'قیمت پیشنهادی (ریال)' : 'Bid Amount (IRR)'}</label>
              <input type="number" className="w-full px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)]" />
              <button className="w-full py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium">
                🏆 {fa ? 'ثبت پیشنهاد' : 'Submit Bid'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
