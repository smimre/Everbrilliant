'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { useRequests, useContracts } from '@/hooks/use-trading';

interface Props { showSales?: boolean; }

export function ReportsPage({ showSales }: Props = {}) {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const { data: requests = [] } = useRequests();
  const { data: contracts = [] } = useContracts();
  const [tab, setTab] = useState<'overview'|'sales'|'contracts'>(showSales ? 'sales' : 'overview');

  const allReqs = requests as any[];
  const allContracts = contracts as any[];

  const byStatus = allReqs.reduce((acc: any, r: any) => {
    acc[r.status] = (acc[r.status] || 0) + 1;
    return acc;
  }, {});

  const totalValue = allReqs.reduce((s: number, r: any) => s + (r.amountIRR || 0), 0);
  const wonValue = allReqs.filter((r: any) => ['paid','completed'].includes(r.status)).reduce((s: number, r: any) => s + (r.amountIRR || 0), 0);
  const convRate = allReqs.length ? Math.round(allReqs.filter((r: any) => ['paid','completed'].includes(r.status)).length / allReqs.length * 100) : 0;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold">📊 {fa ? 'گزارشات' : 'Reports'}</h1>
      </div>

      <div className="flex gap-1 border-b border-[hsl(var(--border))]">
        {[
          { id: 'overview', label: fa ? 'خلاصه' : 'Overview', icon: '📊' },
          { id: 'sales', label: fa ? 'فروش' : 'Sales', icon: '💰' },
          { id: 'contracts', label: fa ? 'قراردادها' : 'Contracts', icon: '📄' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id as any)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === t.id ? 'border-[hsl(var(--primary))] text-[hsl(var(--primary))]' : 'border-transparent text-[hsl(var(--muted-foreground))]'}`}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { icon: '📋', val: allReqs.length, label: fa ? 'کل درخواست‌ها' : 'Total Requests', color: '#3b82f6' },
              { icon: '📄', val: allContracts.length, label: fa ? 'کل قراردادها' : 'Total Contracts', color: '#8b5cf6' },
              { icon: '📈', val: convRate + '%', label: fa ? 'نرخ تبدیل' : 'Conversion Rate', color: '#10b981' },
              { icon: '💰', val: totalValue > 0 ? (totalValue/1000000).toFixed(0)+'M' : '0', label: fa ? 'ارزش کل (ریال)' : 'Total Value', color: '#f59e0b' },
            ].map((s, i) => (
              <div key={i} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4">
                <div className="text-2xl mb-2">{s.icon}</div>
                <div className="text-xl font-bold" style={{ color: s.color }}>{s.val}</div>
                <div className="text-xs text-[hsl(var(--muted-foreground))]">{s.label}</div>
              </div>
            ))}
          </div>

          <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4">
            <h3 className="font-semibold mb-4">{fa ? 'وضعیت درخواست‌ها' : 'Request Status Breakdown'}</h3>
            <div className="space-y-3">
              {Object.entries(byStatus).map(([status, count]: [string, any]) => {
                const pct = allReqs.length ? Math.round(count / allReqs.length * 100) : 0;
                const colors: Record<string,string> = { pending: '#f59e0b', quoted: '#3b82f6', approved: '#8b5cf6', paid: '#06b6d4', completed: '#10b981', rejected: '#ef4444' };
                const labels: Record<string,string> = { pending: fa?'در انتظار':'Pending', quoted: fa?'قیمت داده':'Quoted', approved: fa?'تایید':'Approved', paid: fa?'پرداخت':'Paid', completed: fa?'تکمیل':'Completed', rejected: fa?'رد شده':'Rejected' };
                return (
                  <div key={status}>
                    <div className="flex justify-between text-xs mb-1">
                      <span>{labels[status] || status}</span>
                      <span>{count} ({pct}%)</span>
                    </div>
                    <div className="h-2 rounded-full bg-[hsl(var(--muted)/0.5)]">
                      <div className="h-2 rounded-full transition-all" style={{ width: pct+'%', background: colors[status] || '#64748b' }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {tab === 'sales' && (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            {[
              { icon: '💰', val: wonValue > 0 ? (wonValue/1000000).toFixed(0)+'M' : '0', label: fa ? 'درآمد کسب شده' : 'Revenue Won', color: '#10b981' },
              { icon: '📈', val: convRate + '%', label: fa ? 'نرخ تبدیل' : 'Win Rate', color: '#3b82f6' },
              { icon: '🏆', val: allReqs.filter((r:any) => ['paid','completed'].includes(r.status)).length, label: fa ? 'معاملات موفق' : 'Deals Won', color: '#f59e0b' },
            ].map((s, i) => (
              <div key={i} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4 text-center">
                <div className="text-2xl mb-2">{s.icon}</div>
                <div className="text-xl font-bold" style={{ color: s.color }}>{s.val}</div>
                <div className="text-xs text-[hsl(var(--muted-foreground))]">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'contracts' && (
        <div className="space-y-3">
          {allContracts.length === 0 ? (
            <div className="text-center py-12 text-[hsl(var(--muted-foreground))]">
              <div className="text-3xl mb-2">📄</div>
              <p className="text-sm">{fa ? 'قراردادی ثبت نشده' : 'No contracts'}</p>
            </div>
          ) : allContracts.map((c: any) => (
            <div key={c.id} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4">
              <div className="font-medium text-sm">{c.title}</div>
              <div className="text-xs text-[hsl(var(--muted-foreground))] mt-1">{c.status}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
