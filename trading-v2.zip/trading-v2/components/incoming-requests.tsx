'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { useRequests } from '@/hooks/use-trading';

interface Props { showQuotes?: boolean; }

export function IncomingRequests({ showQuotes }: Props = {}) {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const { data: requests = [] } = useRequests();
  const [selected, setSelected] = useState<any>(null);

  const incoming = (requests as any[]).filter((r) => r.sellerAcc !== undefined);
  const pending = incoming.filter((r: any) => r.status === 'pending');
  const quoted = incoming.filter((r: any) => r.status === 'quoted');
  const won = incoming.filter((r: any) => ['paid','completed'].includes(r.status));

  const display = showQuotes ? quoted : incoming;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold">
          {showQuotes ? (fa ? '💬 پیشنهادهای من' : '💬 My Quotes') : (fa ? '📥 درخواست‌های ورودی' : '📥 Incoming Requests')}
        </h1>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { icon: '📥', val: incoming.length, label: fa ? 'کل دریافتی' : 'Total Received', color: '#3b82f6' },
          { icon: '⏳', val: pending.length, label: fa ? 'نیاز به قیمت' : 'Needs Quoting', color: '#f59e0b' },
          { icon: '💬', val: quoted.length, label: fa ? 'قیمت‌دهی شده' : 'Quoted', color: '#8b5cf6' },
          { icon: '🏆', val: won.length, label: fa ? 'برنده شده' : 'Won', color: '#10b981' },
        ].map((s, i) => (
          <div key={i} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-3 text-center">
            <div className="text-xl mb-1">{s.icon}</div>
            <div className="text-xl font-bold" style={{ color: s.color }}>{s.val}</div>
            <div className="text-xs text-[hsl(var(--muted-foreground))]">{s.label}</div>
          </div>
        ))}
      </div>

      {display.length === 0 ? (
        <div className="text-center py-16 text-[hsl(var(--muted-foreground))]">
          <div className="text-4xl mb-3">📭</div>
          <p className="font-medium">{fa ? 'درخواستی دریافت نشده' : 'No incoming requests'}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {display.map((r: any) => (
            <div key={r.id} onClick={() => setSelected(r)}
              className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4 cursor-pointer hover:border-[hsl(var(--primary)/0.3)] transition-colors">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="font-medium text-sm mb-1">{r.productName || r.title}</div>
                  <div className="flex gap-3 text-xs text-[hsl(var(--muted-foreground))]">
                    {r.quantity && <span>📦 {r.quantity} {r.unit}</span>}
                    {r.createdAt && <span>📅 {r.createdAt}</span>}
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  {r.status === 'pending' && (
                    <button className="px-3 py-1.5 rounded-lg bg-[hsl(var(--primary))] text-white text-xs font-medium"
                      onClick={e => { e.stopPropagation(); }}>
                      {fa ? 'اعلام قیمت' : 'Quote'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-[hsl(var(--secondary))] rounded-2xl border border-[hsl(var(--border))] w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold">📋 {selected.productName || selected.title}</h2>
              <button onClick={() => setSelected(null)} className="text-xl text-[hsl(var(--muted-foreground))]">✕</button>
            </div>
            <div className="space-y-2 text-sm mb-4">
              {selected.quantity && <div className="flex justify-between py-2 border-b border-[hsl(var(--border)/0.5)]"><span className="text-[hsl(var(--muted-foreground))]">{fa ? 'مقدار' : 'Quantity'}</span><span>{selected.quantity} {selected.unit}</span></div>}
              {selected.description && <p className="text-[hsl(var(--muted-foreground))] text-xs">{selected.description}</p>}
            </div>
            {selected.status === 'pending' && (
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">{fa ? 'قیمت پیشنهادی (ریال)' : 'Quote Amount (IRR)'}</label>
                  <input type="number" className="w-full px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)]" />
                </div>
                <button className="w-full py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium">
                  💬 {fa ? 'ارسال قیمت' : 'Send Quote'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
