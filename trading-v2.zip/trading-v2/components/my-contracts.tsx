'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { useContracts } from '@/hooks/use-trading';

const STATUS_MAP: Record<string, { label: string; labelFa: string; color: string; icon: string }> = {
  draft:    { label: 'Draft',    labelFa: 'پیش‌نویس',  color: '#64748b', icon: '📝' },
  signed:   { label: 'Signed',   labelFa: 'امضا شده',  color: '#10b981', icon: '✅' },
  active:   { label: 'Active',   labelFa: 'فعال',       color: '#3b82f6', icon: '🟢' },
  completed:{ label: 'Completed',labelFa: 'تکمیل شده', color: '#8b5cf6', icon: '🏆' },
  cancelled:{ label: 'Cancelled',labelFa: 'لغو شده',   color: '#ef4444', icon: '❌' },
};

export function MyContracts() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const { data: contracts = [], isLoading } = useContracts();
  const [selected, setSelected] = useState<any>(null);
  const [showNew, setShowNew] = useState(false);

  const pending = (contracts as any[]).filter((c) => c.status === 'draft');
  const signed = (contracts as any[]).filter((c) => c.status === 'signed');

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">📄 {fa ? 'قراردادها' : 'My Contracts'}</h1>
          <p className="text-sm text-[hsl(var(--muted-foreground))]">{(contracts as any[]).length} {fa ? 'قرارداد' : 'contracts'}</p>
        </div>
        <button onClick={() => setShowNew(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium hover:opacity-90">
          📄 {fa ? 'قرارداد جدید' : 'New Contract'}
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { icon: '📄', val: (contracts as any[]).length, label: fa ? 'کل قراردادها' : 'All Contracts', color: '#3b82f6' },
          { icon: '✍️', val: pending.length, label: fa ? 'نیاز به امضا' : 'Needs Signing', color: '#ef4444' },
          { icon: '✅', val: signed.length, label: fa ? 'امضا شده' : 'Signed', color: '#10b981' },
          { icon: '📝', val: (contracts as any[]).filter((c: any) => c.status === 'draft').length, label: fa ? 'پیش‌نویس' : 'Draft', color: '#f59e0b' },
        ].map((s, i) => (
          <div key={i} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-3 text-center">
            <div className="text-xl mb-1">{s.icon}</div>
            <div className="text-xl font-bold" style={{ color: s.color }}>{s.val}</div>
            <div className="text-xs text-[hsl(var(--muted-foreground))]">{s.label}</div>
          </div>
        ))}
      </div>

      {pending.length > 0 && (
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-sm text-amber-600 dark:text-amber-400">
          ✍️ <strong>{pending.length} {fa ? 'قرارداد' : 'contract'}</strong> {fa ? 'منتظر امضای شماست!' : 'awaiting your signature!'}
        </div>
      )}

      {/* List */}
      {isLoading ? (
        <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-24 rounded-xl bg-[hsl(var(--muted)/0.5)] animate-pulse" />)}</div>
      ) : (contracts as any[]).length === 0 ? (
        <div className="text-center py-16 text-[hsl(var(--muted-foreground))]">
          <div className="text-4xl mb-3">📄</div>
          <p className="font-medium">{fa ? 'قراردادی ندارید' : 'No contracts yet'}</p>
          <button onClick={() => setShowNew(true)} className="mt-4 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm">
            {fa ? '+ قرارداد جدید' : '+ New Contract'}
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {(contracts as any[]).map((c: any) => (
            <ContractCard key={c.id} contract={c} lang={lang} onClick={() => setSelected(c)} />
          ))}
        </div>
      )}

      {showNew && <NewContractModal lang={lang} onClose={() => setShowNew(false)} />}
      {selected && <ContractDetailModal contract={selected} lang={lang} onClose={() => setSelected(null)} />}
    </div>
  );
}

function ContractCard({ contract: c, lang, onClick }: { contract: any; lang: string; onClick: () => void }) {
  const fa = lang === 'fa';
  const st = STATUS_MAP[c.status] || STATUS_MAP.draft;
  return (
    <div onClick={onClick} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4 cursor-pointer hover:border-[hsl(var(--primary)/0.3)] transition-colors"
      style={{ borderRight: `4px solid ${st.color}` }}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-bold text-sm truncate">{c.title}</span>
            <span className="text-xs px-2 py-0.5 rounded-full shrink-0" style={{ background: st.color + '20', color: st.color }}>
              {st.icon} {fa ? st.labelFa : st.label}
            </span>
          </div>
          <div className="flex flex-wrap gap-3 text-xs text-[hsl(var(--muted-foreground))]">
            {c.product && <span>📦 {c.product}</span>}
            {c.totalPrice && <span>💰 {Number(c.totalPrice).toLocaleString('fa-IR')}</span>}
            {c.deliveryDate && <span>📅 {c.deliveryDate}</span>}
          </div>
        </div>
        <span className="text-xs px-3 py-1.5 rounded-lg border border-[hsl(var(--border))] shrink-0">{fa ? 'جزئیات' : 'Details'}</span>
      </div>
    </div>
  );
}

function NewContractModal({ lang, onClose }: { lang: string; onClose: () => void }) {
  const fa = lang === 'fa';
  const [form, setForm] = useState({ title: '', role: 'buyer', product: '', qty: '', unit: 'ton', unitPrice: '', currency: 'IRR', deliveryDate: '', deliveryPlace: '', paymentTerms: '', incoterms: 'EXW' });
  const incoterms = ['EXW','FCA','FAS','FOB','CFR','CIF','CPT','CIP','DAP','DPU','DDP'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-[hsl(var(--secondary))] rounded-2xl border border-[hsl(var(--border))] w-full max-w-lg p-6 shadow-2xl my-4">
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-bold text-lg">📄 {fa ? 'قرارداد جدید' : 'New Contract'}</h2>
          <button onClick={onClose} className="text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] text-xl">✕</button>
        </div>
        <div className="space-y-3">
          <Field label={fa ? 'عنوان قرارداد *' : 'Contract Title *'}>
            <input value={form.title} onChange={e => setForm({...form, title: e.target.value})} className={inp} placeholder={fa ? 'مثال: قرارداد خرید روغن پالم ۲۰ تن' : 'e.g. Palm Oil Purchase Contract'} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label={fa ? 'نقش من' : 'My Role'}>
              <select value={form.role} onChange={e => setForm({...form, role: e.target.value})} className={inp}>
                <option value="buyer">{fa ? '🏢 خریدار' : '🏢 Buyer'}</option>
                <option value="seller">{fa ? '🏭 فروشنده' : '🏭 Seller'}</option>
              </select>
            </Field>
            <Field label={fa ? 'اینکوترمز' : 'Incoterms'}>
              <select value={form.incoterms} onChange={e => setForm({...form, incoterms: e.target.value})} className={inp}>
                {incoterms.map(i => <option key={i} value={i}>{i}</option>)}
              </select>
            </Field>
          </div>
          <Field label={fa ? 'کالا / خدمات' : 'Product / Service'}>
            <input value={form.product} onChange={e => setForm({...form, product: e.target.value})} className={inp} />
          </Field>
          <div className="grid grid-cols-3 gap-3">
            <Field label={fa ? 'مقدار' : 'Quantity'}>
              <input value={form.qty} onChange={e => setForm({...form, qty: e.target.value})} type="number" className={inp} />
            </Field>
            <Field label={fa ? 'واحد' : 'Unit'}>
              <select value={form.unit} onChange={e => setForm({...form, unit: e.target.value})} className={inp}>
                {['ton','kg','unit','m','m2','m3','liter'].map(u => <option key={u} value={u}>{u}</option>)}
              </select>
            </Field>
            <Field label={fa ? 'قیمت واحد' : 'Unit Price'}>
              <input value={form.unitPrice} onChange={e => setForm({...form, unitPrice: e.target.value})} type="number" className={inp} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label={fa ? 'تاریخ تحویل' : 'Delivery Date'}>
              <input value={form.deliveryDate} onChange={e => setForm({...form, deliveryDate: e.target.value})} className={inp} placeholder="1403/06/15" />
            </Field>
            <Field label={fa ? 'محل تحویل' : 'Delivery Place'}>
              <input value={form.deliveryPlace} onChange={e => setForm({...form, deliveryPlace: e.target.value})} className={inp} />
            </Field>
          </div>
          <Field label={fa ? 'شرایط پرداخت' : 'Payment Terms'}>
            <input value={form.paymentTerms} onChange={e => setForm({...form, paymentTerms: e.target.value})} className={inp} placeholder={fa ? 'مثال: ۳۰ روزه' : 'e.g. 30 days'} />
          </Field>
        </div>
        <div className="flex gap-3 mt-5">
          <button onClick={onClose} className="flex-1 px-4 py-2 rounded-lg border border-[hsl(var(--border))] text-sm">{fa ? 'انصراف' : 'Cancel'}</button>
          <button className="flex-1 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium">{fa ? '✅ ثبت قرارداد' : '✅ Create'}</button>
        </div>
      </div>
    </div>
  );
}

function ContractDetailModal({ contract: c, lang, onClose }: { contract: any; lang: string; onClose: () => void }) {
  const fa = lang === 'fa';
  const st = STATUS_MAP[c.status] || STATUS_MAP.draft;
  const rows = [
    [fa ? 'کالا/خدمات' : 'Product', c.product],
    [fa ? 'اینکوترمز' : 'Incoterms', c.incoterms],
    [fa ? 'ارز' : 'Currency', c.currency],
    [fa ? 'تاریخ تحویل' : 'Delivery Date', c.deliveryDate],
    [fa ? 'محل تحویل' : 'Delivery Place', c.deliveryPlace],
    [fa ? 'شرایط پرداخت' : 'Payment Terms', c.paymentTerms],
  ].filter(r => r[1]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-[hsl(var(--secondary))] rounded-2xl border border-[hsl(var(--border))] w-full max-w-md p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold">📄 {c.title}</h2>
          <button onClick={onClose} className="text-[hsl(var(--muted-foreground))] text-xl">✕</button>
        </div>
        <span className="text-xs px-2 py-1 rounded-full mb-4 inline-block" style={{ background: st.color + '20', color: st.color }}>
          {st.icon} {fa ? st.labelFa : st.label}
        </span>
        <div className="space-y-2 mt-3">
          {rows.map(([k, v]) => (
            <div key={k} className="flex justify-between text-sm py-2 border-b border-[hsl(var(--border)/0.5)]">
              <span className="text-[hsl(var(--muted-foreground))]">{k}</span>
              <span className="font-medium">{v}</span>
            </div>
          ))}
        </div>
        {c.status === 'draft' && (
          <button className="w-full mt-5 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium">
            ✍️ {fa ? 'امضای قرارداد' : 'Sign Contract'}
          </button>
        )}
      </div>
    </div>
  );
}

const inp = "w-full px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)]";
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div><label className="text-xs font-medium mb-1 block text-[hsl(var(--muted-foreground))]">{label}</label>{children}</div>;
}
