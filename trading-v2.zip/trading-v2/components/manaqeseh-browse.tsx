'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';

export function ManaqesehBrowse() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  
  const [items] = useState<any[]>([]);
  const statuses = [
    { icon: '📋', val: items.length, label: fa ? 'مناقصه باز' : 'Open Tenders', color: '#3b82f6' },
    { icon: '🤝', val: 0, label: fa ? 'شرکت کرده‌ام' : 'Participated', color: '#8b5cf6' },
    { icon: '📢', val: 0, label: fa ? 'برگزارکننده' : 'My Own', color: '#f59e0b' },
    { icon: '🏆', val: 0, label: fa ? 'برنده شده' : 'Won', color: '#10b981' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">{fa ? '📋 مناقصه‌ها' : '📋 Tenders'}</h1>
        
      </div>

      <div className="grid grid-cols-4 gap-3">
        {statuses.map((s, i) => (
          <div key={i} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-3 text-center">
            <div className="text-xl mb-1">{s.icon}</div>
            <div className="text-xl font-bold" style={{ color: s.color }}>{s.val}</div>
            <div className="text-xs text-[hsl(var(--muted-foreground))]">{s.label}</div>
          </div>
        ))}
      </div>

      {items.length === 0 ? (
        <div className="text-center py-16 text-[hsl(var(--muted-foreground))]">
          <div className="text-4xl mb-3">📋 </div>
          <p className="font-medium">{fa ? 'موردی یافت نشد' : 'Nothing found'}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((item: any) => (
            <div key={item.id} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4">
              <div className="font-medium text-sm">{item.title || item.name}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
