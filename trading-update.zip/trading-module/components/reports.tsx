'use client';
import { useLocaleStore } from '@/store/locale.store';

export function ReportsPage({ showNew, showQuotes, showSales }: { showNew?: boolean; showQuotes?: boolean; showSales?: boolean; } = {}) {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold">{fa ? '📊 گزارشات' : '📊 Reports'}</h1>
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-8 text-center">
        <div className="text-4xl mb-3">🚧</div>
        <p className="font-medium">{fa ? 'در حال توسعه' : 'Under Development'}</p>
        <p className="text-sm text-[hsl(var(--muted-foreground))] mt-1">
          {fa ? 'این بخش به زودی تکمیل می‌شود' : 'This section will be completed soon'}
        </p>
      </div>
    </div>
  );
}
