'use client';
import { useLocaleStore } from '@/store/locale.store';
import { useRequests, useContracts, useTenders } from '@/hooks/use-trading';

interface Props { onNavigate: (view: any) => void; }

export function TradingDashboard({ onNavigate }: Props) {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const { data: requests = [] } = useRequests();
  const { data: contracts = [] } = useContracts();
  const { data: tenders = [] } = useTenders();

  const pendingReqs = requests.filter((r: any) => r.status === 'pending').length;
  const activeContracts = contracts.filter((c: any) => c.status === 'active').length;
  const openTenders = tenders.filter((t: any) => t.status === 'open').length;

  const stats = [
    { icon: '📋', value: requests.length, label: fa ? 'کل درخواست‌ها' : 'Total Requests', color: 'bl', sub: `${pendingReqs} ${fa ? 'در انتظار' : 'pending'}` },
    { icon: '📄', value: contracts.length, label: fa ? 'قراردادها' : 'Contracts', color: 'gr', sub: `${activeContracts} ${fa ? 'فعال' : 'active'}` },
    { icon: '🏷️', value: tenders.length, label: fa ? 'مزایده‌ها' : 'Tenders', color: 'gd', sub: `${openTenders} ${fa ? 'باز' : 'open'}` },
    { icon: '🤝', value: 0, label: fa ? 'اتصالات' : 'Connections', color: 'pu', sub: fa ? 'شرکای تجاری' : 'Partners' },
  ];

  const quickActions = [
    { icon: '➕', label: fa ? 'درخواست جدید' : 'New Request', view: 'my-requests', color: '#3b82f6' },
    { icon: '📄', label: fa ? 'قرارداد جدید' : 'New Contract', view: 'my-contracts', color: '#10b981' },
    { icon: '🏷️', label: fa ? 'مزایده جدید' : 'New Tender', view: 'tender-new', color: '#f59e0b' },
    { icon: '🔗', label: fa ? 'دعوت همکار' : 'Invite Partner', view: 'connections', color: '#8b5cf6' },
    { icon: '🎯', label: fa ? 'CRM', view: 'crm', color: '#06b6d4' },
    { icon: '📊', label: fa ? 'گزارشات' : 'Reports', view: 'reports', color: '#ec4899' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">{fa ? '📊 داشبورد بازرگانی' : '📊 Trading Dashboard'}</h1>
        <p className="text-[hsl(var(--muted-foreground))] text-sm mt-1">{fa ? 'خلاصه فعالیت‌های تجاری شما' : 'Overview of your trading activity'}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, i) => (
          <div key={i} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4">
            <div className="text-2xl mb-2">{s.icon}</div>
            <div className="text-2xl font-bold">{s.value}</div>
            <div className="text-sm text-[hsl(var(--muted-foreground))]">{s.label}</div>
            <div className="text-xs text-[hsl(var(--muted-foreground))] mt-1">{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4">
        <h2 className="font-semibold mb-4">⚡ {fa ? 'دسترسی سریع' : 'Quick Actions'}</h2>
        <div className="grid grid-cols-3 lg:grid-cols-6 gap-3">
          {quickActions.map((a, i) => (
            <button key={i} onClick={() => onNavigate(a.view)}
              className="flex flex-col items-center gap-2 p-3 rounded-xl border border-[hsl(var(--border))] hover:border-[hsl(var(--primary)/0.4)] hover:bg-[hsl(var(--muted)/0.5)] transition-all group"
            >
              <div className="rounded-xl p-2 group-hover:scale-110 transition-transform text-xl" style={{ background: `${a.color}18`, color: a.color }}>
                {a.icon}
              </div>
              <span className="text-xs font-medium text-center leading-tight text-[hsl(var(--muted-foreground))] group-hover:text-[hsl(var(--foreground))]">
                {a.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Requests */}
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold">📋 {fa ? 'آخرین درخواست‌ها' : 'Recent Requests'}</h2>
          <button onClick={() => onNavigate('my-requests')}
            className="text-xs text-[hsl(var(--primary))] hover:underline"
          >{fa ? 'مشاهده همه' : 'View all'}</button>
        </div>
        {requests.length === 0 ? (
          <div className="text-center py-8 text-[hsl(var(--muted-foreground))]">
            <div className="text-3xl mb-2">📭</div>
            <p className="text-sm">{fa ? 'هنوز درخواستی ثبت نشده' : 'No requests yet'}</p>
          </div>
        ) : (
          <div className="space-y-2">
            {requests.slice(0, 5).map((r: any) => (
              <div key={r.id} className="flex items-center justify-between p-3 rounded-lg bg-[hsl(var(--muted)/0.3)] hover:bg-[hsl(var(--muted)/0.5)] transition-colors">
                <div>
                  <div className="text-sm font-medium">{r.productName || r.title}</div>
                  <div className="text-xs text-[hsl(var(--muted-foreground))]">{r.createdAt}</div>
                </div>
                <StatusBadge status={r.status} lang={lang} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StatusBadge({ status, lang }: { status: string; lang: string }) {
  const fa = lang === 'fa';
  const map: Record<string, { label: string; labelFa: string; color: string }> = {
    pending:   { label: 'Pending',   labelFa: 'در انتظار',   color: '#f59e0b' },
    quoted:    { label: 'Quoted',    labelFa: 'قیمت داده شد', color: '#3b82f6' },
    approved:  { label: 'Approved',  labelFa: 'تایید شده',   color: '#10b981' },
    paid:      { label: 'Paid',      labelFa: 'پرداخت شده',  color: '#06b6d4' },
    completed: { label: 'Completed', labelFa: 'تکمیل شده',  color: '#8b5cf6' },
    rejected:  { label: 'Rejected',  labelFa: 'رد شده',      color: '#ef4444' },
  };
  const s = map[status] || { label: status, labelFa: status, color: '#64748b' };
  return (
    <span className="text-xs px-2 py-1 rounded-full font-medium" style={{ background: `${s.color}20`, color: s.color }}>
      {fa ? s.labelFa : s.label}
    </span>
  );
}
