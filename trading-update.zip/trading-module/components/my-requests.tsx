'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { useRequests } from '@/hooks/use-trading';

export function MyRequests() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const { data: requests = [], isLoading } = useRequests();
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [showNew, setShowNew] = useState(false);

  const statuses = ['all', 'pending', 'quoted', 'approved', 'paid', 'completed', 'rejected'];

  const filtered = requests.filter((r: any) => {
    const matchStatus = filter === 'all' || r.status === filter;
    const matchSearch = !search || (r.productName || r.title || '').toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  const statusLabel: Record<string, string> = {
    all: fa ? 'همه' : 'All',
    pending: fa ? 'در انتظار' : 'Pending',
    quoted: fa ? 'قیمت داده' : 'Quoted',
    approved: fa ? 'تایید شده' : 'Approved',
    paid: fa ? 'پرداخت شده' : 'Paid',
    completed: fa ? 'تکمیل' : 'Completed',
    rejected: fa ? 'رد شده' : 'Rejected',
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">📋 {fa ? 'درخواست‌های من' : 'My Requests'}</h1>
          <p className="text-sm text-[hsl(var(--muted-foreground))]">{filtered.length} {fa ? 'درخواست' : 'requests'}</p>
        </div>
        <button onClick={() => setShowNew(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium hover:opacity-90 transition-opacity"
        >
          ➕ {fa ? 'درخواست جدید' : 'New Request'}
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-2 flex-wrap">
        {statuses.map(s => (
          <button key={s} onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              filter === s
                ? 'bg-[hsl(var(--primary))] text-white'
                : 'bg-[hsl(var(--muted)/0.5)] text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]'
            }`}
          >{statusLabel[s]}</button>
        ))}
      </div>

      {/* Search */}
      <input
        value={search}
        onChange={e => setSearch(e.target.value)}
        placeholder={fa ? 'جستجو در درخواست‌ها...' : 'Search requests...'}
        className="w-full px-4 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)]"
      />

      {/* List */}
      {isLoading ? (
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="h-20 rounded-xl bg-[hsl(var(--muted)/0.5)] animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-[hsl(var(--muted-foreground))]">
          <div className="text-4xl mb-3">📭</div>
          <p className="font-medium">{fa ? 'درخواستی یافت نشد' : 'No requests found'}</p>
          <p className="text-sm mt-1">{fa ? 'درخواست جدید ثبت کنید' : 'Create a new request'}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((r: any) => (
            <RequestCard key={r.id} request={r} lang={lang} />
          ))}
        </div>
      )}

      {showNew && <NewRequestModal lang={lang} onClose={() => setShowNew(false)} />}
    </div>
  );
}

function RequestCard({ request: r, lang }: { request: any; lang: string }) {
  const fa = lang === 'fa';
  const statusColors: Record<string, string> = {
    pending: '#f59e0b', quoted: '#3b82f6', approved: '#10b981',
    paid: '#06b6d4', completed: '#8b5cf6', rejected: '#ef4444',
  };
  const statusLabels: Record<string, string> = {
    pending: fa ? 'در انتظار' : 'Pending',
    quoted: fa ? 'قیمت داده' : 'Quoted',
    approved: fa ? 'تایید شده' : 'Approved',
    paid: fa ? 'پرداخت شده' : 'Paid',
    completed: fa ? 'تکمیل شده' : 'Completed',
    rejected: fa ? 'رد شده' : 'Rejected',
  };
  const color = statusColors[r.status] || '#64748b';

  return (
    <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4 hover:border-[hsl(var(--primary)/0.3)] transition-colors cursor-pointer">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-semibold text-sm truncate">{r.productName || r.title || fa ? 'درخواست' : 'Request'}</span>
            <span className="text-xs px-2 py-0.5 rounded-full font-medium shrink-0" style={{ background: `${color}20`, color }}>
              {statusLabels[r.status] || r.status}
            </span>
          </div>
          <div className="flex items-center gap-4 text-xs text-[hsl(var(--muted-foreground))]">
            {r.quantity && <span>📦 {r.quantity} {r.unit || ''}</span>}
            {r.amountIRR && <span>💰 {Number(r.amountIRR).toLocaleString('fa-IR')} ریال</span>}
            {r.createdAt && <span>📅 {r.createdAt}</span>}
          </div>
          {r.description && (
            <p className="text-xs text-[hsl(var(--muted-foreground))] mt-2 line-clamp-2">{r.description}</p>
          )}
        </div>
        <button className="text-xs px-3 py-1.5 rounded-lg border border-[hsl(var(--border))] hover:bg-[hsl(var(--muted)/0.5)] transition-colors shrink-0">
          {fa ? 'جزئیات' : 'Details'}
        </button>
      </div>
    </div>
  );
}

function NewRequestModal({ lang, onClose }: { lang: string; onClose: () => void }) {
  const fa = lang === 'fa';
  const [form, setForm] = useState({ productName: '', quantity: '', unit: 'ton', description: '' });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-[hsl(var(--secondary))] rounded-2xl border border-[hsl(var(--border))] w-full max-w-md p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-bold text-lg">➕ {fa ? 'درخواست جدید' : 'New Request'}</h2>
          <button onClick={onClose} className="text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] text-xl">✕</button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1 block">{fa ? 'نام کالا / خدمات *' : 'Product / Service *'}</label>
            <input value={form.productName} onChange={e => setForm({...form, productName: e.target.value})}
              className="w-full px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)]"
              placeholder={fa ? 'مثال: فولاد ساختمانی' : 'e.g. Construction Steel'} />
          </div>
          <div className="flex gap-3">
            <div className="flex-1">
              <label className="text-sm font-medium mb-1 block">{fa ? 'مقدار' : 'Quantity'}</label>
              <input value={form.quantity} onChange={e => setForm({...form, quantity: e.target.value})}
                type="number"
                className="w-full px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)]" />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">{fa ? 'واحد' : 'Unit'}</label>
              <select value={form.unit} onChange={e => setForm({...form, unit: e.target.value})}
                className="px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm focus:outline-none">
                <option value="ton">{fa ? 'تن' : 'Ton'}</option>
                <option value="kg">Kg</option>
                <option value="unit">{fa ? 'عدد' : 'Unit'}</option>
                <option value="m">{fa ? 'متر' : 'Meter'}</option>
              </select>
            </div>
          </div>
          <div>
            <label className="text-sm font-medium mb-1 block">{fa ? 'توضیحات' : 'Description'}</label>
            <textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})}
              rows={3}
              className="w-full px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)] resize-none" />
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <button onClick={onClose} className="flex-1 px-4 py-2 rounded-lg border border-[hsl(var(--border))] text-sm hover:bg-[hsl(var(--muted)/0.5)] transition-colors">
            {fa ? 'انصراف' : 'Cancel'}
          </button>
          <button className="flex-1 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium hover:opacity-90 transition-opacity">
            {fa ? '✅ ثبت درخواست' : '✅ Submit'}
          </button>
        </div>
      </div>
    </div>
  );
}
