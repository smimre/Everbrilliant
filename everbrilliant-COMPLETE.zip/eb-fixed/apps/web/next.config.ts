import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  // Standalone output for Docker / PM2
  output: 'standalone',

  // Transpile shared packages
  transpilePackages: ['@everbrilliant/ui', '@everbrilliant/types'],

  // Image optimization
  images: {
    domains: ['localhost'],
    formats: ['image/avif', 'image/webp'],
    minimumCacheTTL: 3600,
    deviceSizes: [390, 640, 768, 1024, 1280, 1920],
  },

  // Experimental features
  experimental: {
    optimizePackageImports: ['lucide-react', '@tanstack/react-query'],
  },

  // Webpack optimizations
  webpack(config, { isServer, dev }) {
    if (!dev && !isServer) {
      config.optimization = {
        ...config.optimization,
        usedExports: true,
        sideEffects: true,
        splitChunks: {
          chunks: 'all',
          cacheGroups: {
            vendor: {
              test: /node_modules/,
              name: 'vendors',
              chunks: 'all' as const,
              priority: 10,
            },
            realtime: {
              test: /socket\.io/,
              name: 'realtime',
              chunks: 'async' as const,
              priority: 20,
            },
          },
        },
      };
    }
    return config;
  },

  // Headers for security + performance
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
        ],
      },
      {
        source: '/fonts/:path*',
        headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }],
      },
      {
        source: '/_next/static/:path*',
        headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }],
      },
    ];
  },

  // Redirects
  async redirects() {
    return [
      { source: '/', destination: '/dashboard', permanent: false },
    ];
  },
};

export default nextConfig;
