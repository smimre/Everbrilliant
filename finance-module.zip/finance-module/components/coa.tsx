'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';

const ACC_TYPES = [
  { id: 'asset',     icon: '🏛️', labelFa: 'دارایی',           label: 'Assets',      color: '#3b82f6' },
  { id: 'liability', icon: '📤', labelFa: 'بدهی',             label: 'Liabilities', color: '#ef4444' },
  { id: 'equity',    icon: '⚖️', labelFa: 'حقوق صاحبان',     label: 'Equity',      color: '#8b5cf6' },
  { id: 'revenue',   icon: '📈', labelFa: 'درآمد',            label: 'Revenue',     color: '#10b981' },
  { id: 'expense',   icon: '📉', labelFa: 'هزینه',            label: 'Expenses',    color: '#f59e0b' },
];

export function ChartOfAccounts() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const [accounts, setAccounts] = useState<any[]>([]);
  const [showNew, setShowNew] = useState(false);
  const [form, setForm] = useState({ code: '', name: '', nameFa: '', type: 'asset', normal: 'debit' });

  const inp = "w-full px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)]";

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">📋 {fa ? 'سرفصل حساب‌ها' : 'Chart of Accounts'}</h1>
          <p className="text-sm text-[hsl(var(--muted-foreground))]">{accounts.length} {fa ? 'حساب' : 'accounts'}</p>
        </div>
        <button onClick={() => setShowNew(true)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium">
          ➕ {fa ? 'حساب جدید' : 'New Account'}
        </button>
      </div>

      {/* Type groups */}
      <div className="space-y-4">
        {ACC_TYPES.map(type => {
          const typeAccs = accounts.filter((a: any) => a.type === type.id);
          const total = typeAccs.reduce((s: number, a: any) => s + (a.balance || 0), 0);
          return (
            <div key={type.id} className="rounded-xl border border-[hsl(var(--border))] overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 bg-[hsl(var(--muted)/0.3)]">
                <div className="flex items-center gap-2">
                  <span>{type.icon}</span>
                  <span className="font-semibold text-sm">{fa ? type.labelFa : type.label}</span>
                  <span className="text-xs text-[hsl(var(--muted-foreground))]">({typeAccs.length})</span>
                </div>
                <span className="text-sm font-bold" style={{ color: type.color }}>
                  {total.toLocaleString('fa-IR')}
                </span>
              </div>
              {typeAccs.length > 0 ? (
                <table className="w-full text-sm">
                  <thead className="bg-[hsl(var(--muted)/0.2)]">
                    <tr>
                      {[fa?'کد':'Code', fa?'نام حساب':'Account Name', fa?'بدهکار':'Debit', fa?'بستانکار':'Credit', fa?'مانده':'Balance'].map(h => (
                        <th key={h} className="text-start px-4 py-2 text-xs font-semibold text-[hsl(var(--muted-foreground))]">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {typeAccs.map((a: any) => (
                      <tr key={a.id} className="border-t border-[hsl(var(--border)/0.5)] hover:bg-[hsl(var(--muted)/0.3)]">
                        <td className="px-4 py-2 font-mono text-xs">{a.code}</td>
                        <td className="px-4 py-2 font-medium">{fa ? a.nameFa || a.name : a.name}</td>
                        <td className="px-4 py-2 text-green-600">{a.debit ? a.debit.toLocaleString('fa-IR') : '-'}</td>
                        <td className="px-4 py-2 text-red-500">{a.credit ? a.credit.toLocaleString('fa-IR') : '-'}</td>
                        <td className="px-4 py-2 font-bold" style={{ color: type.color }}>{(a.balance || 0).toLocaleString('fa-IR')}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="px-4 py-3 text-sm text-[hsl(var(--muted-foreground))]">
                  {fa ? 'حسابی در این دسته ثبت نشده' : 'No accounts in this category'}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {showNew && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-[hsl(var(--secondary))] rounded-2xl border border-[hsl(var(--border))] w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-bold text-lg">➕ {fa ? 'حساب جدید' : 'New Account'}</h2>
              <button onClick={() => setShowNew(false)} className="text-xl text-[hsl(var(--muted-foreground))]">✕</button>
            </div>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">{fa?'کد حساب *':'Account Code *'}</label>
                  <input value={form.code} onChange={e => setForm({...form, code: e.target.value})} className={inp} placeholder="1100" />
                </div>
                <div>
                  <label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">{fa?'نوع حساب':'Type'}</label>
                  <select value={form.type} onChange={e => setForm({...form, type: e.target.value})} className={inp}>
                    {ACC_TYPES.map(t => <option key={t.id} value={t.id}>{fa ? t.labelFa : t.label}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">{fa?'نام حساب *':'Account Name *'}</label>
                <input value={form.nameFa} onChange={e => setForm({...form, nameFa: e.target.value})} className={inp} placeholder={fa?'موجودی نقد':'Cash'} />
              </div>
              <div>
                <label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">{fa?'ماهیت':'Normal Balance'}</label>
                <select value={form.normal} onChange={e => setForm({...form, normal: e.target.value})} className={inp}>
                  <option value="debit">{fa?'بدهکار':'Debit'}</option>
                  <option value="credit">{fa?'بستانکار':'Credit'}</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setShowNew(false)} className="flex-1 px-4 py-2 rounded-lg border border-[hsl(var(--border))] text-sm">{fa?'انصراف':'Cancel'}</button>
              <button className="flex-1 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm font-medium">✅ {fa?'ذخیره':'Save'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
