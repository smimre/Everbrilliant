// این خطوط رو به finance/index.tsx اضافه کن:
// 1. import:
// import { DualLedgerSystem } from './components/dual-ledger-system';
// 2. در NAV array:
// { id: 'dual-books', label: 'Dual-Book Accounting', labelFa: 'سیستم دفتر دوگانه', icon: '📚', section: 'accounting' },
// 3. در switch:
// case 'dual-books': return <DualLedgerSystem />;
