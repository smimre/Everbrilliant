'use client';
import { useLocaleStore } from '@/store/locale.store';

export function TrialBalance() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const accounts: any[] = [];
  const totalDr = 0, totalCr = 0;
  const balanced = totalDr === totalCr;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">⚖️ {fa ? 'تراز آزمایشی' : 'Trial Balance'}</h1>
        <button className="px-4 py-2 rounded-lg border border-[hsl(var(--border))] text-sm hover:bg-[hsl(var(--muted)/0.5)]">
          🖨️ {fa ? 'چاپ' : 'Print'}
        </button>
      </div>
      {balanced && accounts.length > 0 && (
        <div className="rounded-xl bg-green-500/10 border border-green-500/30 p-3 text-sm text-green-600">
          ✅ {fa ? 'حساب‌ها تراز است' : 'Accounts are balanced'}
        </div>
      )}
      <div className="rounded-xl border border-[hsl(var(--border))] overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-[hsl(var(--muted)/0.5)]">
            <tr>
              {[fa?'کد':'Code', fa?'نام حساب':'Account', fa?'بدهکار':'Debit', fa?'بستانکار':'Credit'].map(h => (
                <th key={h} className="text-start px-4 py-3 text-xs font-semibold text-[hsl(var(--muted-foreground))]">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {accounts.length === 0 ? (
              <tr><td colSpan={4} className="px-4 py-8 text-center text-[hsl(var(--muted-foreground))]">{fa?'حسابی ثبت نشده':'No accounts'}</td></tr>
            ) : accounts.map((a: any) => (
              <tr key={a.id} className="border-t border-[hsl(var(--border)/0.5)] hover:bg-[hsl(var(--muted)/0.3)]">
                <td className="px-4 py-2 font-mono text-xs">{a.code}</td>
                <td className="px-4 py-2">{fa ? a.nameFa||a.name : a.name}</td>
                <td className="px-4 py-2 text-green-600">{a.debit?.toLocaleString('fa-IR') || '-'}</td>
                <td className="px-4 py-2 text-red-500">{a.credit?.toLocaleString('fa-IR') || '-'}</td>
              </tr>
            ))}
            <tr className="border-t-2 border-[hsl(var(--border))] bg-[hsl(var(--muted)/0.3)] font-bold">
              <td colSpan={2} className="px-4 py-3">{fa?'جمع کل':'Total'}</td>
              <td className="px-4 py-3 text-green-600">{totalDr.toLocaleString('fa-IR')}</td>
              <td className="px-4 py-3 text-red-500">{totalCr.toLocaleString('fa-IR')}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
