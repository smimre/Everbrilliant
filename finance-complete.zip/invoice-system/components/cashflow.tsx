'use client';
import { useLocaleStore } from '@/store/locale.store';

export function Cashflow() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const months = fa ? ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور'] : ['Jan','Feb','Mar','Apr','May','Jun'];
  const inData = [120,145,98,165,142,178].map(x => x * 1000000);
  const outData = [85,110,72,130,115,145].map(x => x * 1000000);
  const maxVal = Math.max(...inData, ...outData);

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold">💸 {fa?'جریان نقدی':'Cash Flow'}</h1>
      <div className="grid grid-cols-3 gap-3">
        {[
          { icon: '📥', val: (inData.reduce((a,b)=>a+b,0)/1000000).toFixed(0)+'M', label: fa?'کل ورودی':'Total In', color: '#10b981' },
          { icon: '📤', val: (outData.reduce((a,b)=>a+b,0)/1000000).toFixed(0)+'M', label: fa?'کل خروجی':'Total Out', color: '#ef4444' },
          { icon: '💰', val: ((inData.reduce((a,b)=>a+b,0)-outData.reduce((a,b)=>a+b,0))/1000000).toFixed(0)+'M', label: fa?'خالص':'Net Flow', color: '#3b82f6' },
        ].map((s,i) => (
          <div key={i} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4 text-center">
            <div className="text-2xl mb-2">{s.icon}</div>
            <div className="text-xl font-bold" style={{color:s.color}}>{s.val}</div>
            <div className="text-xs text-[hsl(var(--muted-foreground))]">{s.label}</div>
          </div>
        ))}
      </div>
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4">
        <h3 className="font-semibold mb-4">{fa?'نمودار ۶ ماهه':'6-Month Chart'}</h3>
        <div className="flex items-end gap-2 h-40">
          {months.map((m, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div className="w-full flex gap-0.5 items-end" style={{height:'120px'}}>
                <div className="flex-1 rounded-t" style={{height: (inData[i]/maxVal*100)+'%', background:'#10b981', opacity:0.8}} />
                <div className="flex-1 rounded-t" style={{height: (outData[i]/maxVal*100)+'%', background:'#ef4444', opacity:0.8}} />
              </div>
              <div className="text-[10px] text-[hsl(var(--muted-foreground))]">{m}</div>
            </div>
          ))}
        </div>
        <div className="flex gap-4 mt-2 text-xs">
          <span className="flex items-center gap-1"><div className="w-3 h-3 rounded" style={{background:'#10b981'}} /> {fa?'ورودی':'Inflow'}</span>
          <span className="flex items-center gap-1"><div className="w-3 h-3 rounded" style={{background:'#ef4444'}} /> {fa?'خروجی':'Outflow'}</span>
        </div>
      </div>
    </div>
  );
}
