'use client';
import { useLocaleStore } from '@/store/locale.store';

export function IncomeStatement() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const rows = [
    { label: fa?'درآمد فروش':'Revenue', value: 0, type: 'revenue' },
    { label: fa?'بهای تمام شده':'COGS', value: 0, type: 'cogs' },
    { label: fa?'سود ناخالص':'Gross Profit', value: 0, type: 'subtotal' },
    { label: fa?'هزینه حقوق':'Salaries', value: 0, type: 'expense' },
    { label: fa?'هزینه اجاره':'Rent', value: 0, type: 'expense' },
    { label: fa?'هزینه بازاریابی':'Marketing', value: 0, type: 'expense' },
    { label: fa?'سایر هزینه‌ها':'Other Expenses', value: 0, type: 'expense' },
    { label: fa?'سود/زیان عملیاتی':'Operating Profit', value: 0, type: 'total' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">📈 {fa?'صورت سود و زیان':'Income Statement'}</h1>
        <button className="px-4 py-2 rounded-lg border border-[hsl(var(--border))] text-sm">🖨️ {fa?'چاپ':'Print'}</button>
      </div>
      <div className="rounded-xl border border-[hsl(var(--border))] overflow-hidden">
        <table className="w-full text-sm">
          <tbody>
            {rows.map((row, i) => (
              <tr key={i} className={`border-t border-[hsl(var(--border)/0.5)] ${row.type === 'subtotal' ? 'bg-blue-500/5 font-semibold' : row.type === 'total' ? 'bg-[hsl(var(--muted)/0.5)] font-bold text-base' : 'hover:bg-[hsl(var(--muted)/0.3)]'}`}>
                <td className="px-4 py-3">{row.label}</td>
                <td className={`px-4 py-3 text-end font-mono ${row.type === 'cogs' || row.type === 'expense' ? 'text-red-500' : 'text-green-600'}`}>
                  {row.value.toLocaleString('fa-IR')}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
