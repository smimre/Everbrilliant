'use client';
import { useLocaleStore } from '@/store/locale.store';

export function FinanceReports() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const reports = [
    { icon: '📊', title: fa?'ترازنامه':'Balance Sheet', desc: fa?'دارایی، بدهی و حقوق صاحبان':'Assets, Liabilities, Equity', view: 'balance-sheet' },
    { icon: '📈', title: fa?'صورت سود و زیان':'Income Statement', desc: fa?'درآمد، هزینه و سود':'Revenue, Expense, Profit', view: 'income-stmt' },
    { icon: '💸', title: fa?'جریان نقدی':'Cash Flow', desc: fa?'ورودی و خروجی نقدی':'Cash In & Out', view: 'cashflow' },
    { icon: '⚖️', title: fa?'تراز آزمایشی':'Trial Balance', desc: fa?'بدهکار و بستانکار حساب‌ها':'Debit & Credit Summary', view: 'trial-balance' },
    { icon: '🎯', title: fa?'بودجه در مقابل واقعی':'Budget vs Actual', desc: fa?'مقایسه بودجه با عملکرد':'Budget Performance', view: 'budget' },
    { icon: '🧾', title: fa?'گزارش فاکتورها':'Invoice Report', desc: fa?'خلاصه فاکتورهای صادره و دریافتی':'Invoice Summary', view: 'invoices' },
  ];

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold">📋 {fa?'گزارشات مالی':'Financial Reports'}</h1>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {reports.map((r, i) => (
          <div key={i} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4 cursor-pointer hover:border-[hsl(var(--primary)/0.3)] transition-colors">
            <div className="text-3xl mb-3">{r.icon}</div>
            <div className="font-semibold text-sm mb-1">{r.title}</div>
            <div className="text-xs text-[hsl(var(--muted-foreground))]">{r.desc}</div>
            <button className="mt-3 text-xs text-[hsl(var(--primary))] hover:underline">{fa?'مشاهده گزارش →':'View Report →'}</button>
          </div>
        ))}
      </div>
    </div>
  );
}
