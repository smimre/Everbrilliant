'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';

export function Budget() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const [items, setItems] = useState<any[]>([]);
  const [showNew, setShowNew] = useState(false);
  const inp = "w-full px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--background))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--primary)/0.3)]";

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">🎯 {fa?'بودجه‌بندی':'Budget'}</h1>
        <button onClick={() => setShowNew(true)} className="px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm">
          ➕ {fa?'آیتم بودجه':'Add Budget Item'}
        </button>
      </div>
      {items.length === 0 ? (
        <div className="text-center py-16 text-[hsl(var(--muted-foreground))]">
          <div className="text-4xl mb-3">🎯</div>
          <p className="font-medium">{fa?'بودجه‌ای تعریف نشده':'No budget items'}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((item: any) => {
            const pct = item.budgeted ? Math.round(item.actual / item.budgeted * 100) : 0;
            return (
              <div key={item.id} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-4">
                <div className="flex justify-between mb-2">
                  <span className="font-medium text-sm">{item.name}</span>
                  <span className="text-xs text-[hsl(var(--muted-foreground))]">{pct}% {fa?'مصرف شده':'used'}</span>
                </div>
                <div className="h-2 rounded-full bg-[hsl(var(--muted)/0.5)]">
                  <div className="h-2 rounded-full" style={{width: Math.min(pct,100)+'%', background: pct>90?'#ef4444':pct>70?'#f59e0b':'#10b981'}} />
                </div>
                <div className="flex justify-between mt-1 text-xs text-[hsl(var(--muted-foreground))]">
                  <span>{fa?'واقعی:':'Actual:'} {item.actual?.toLocaleString('fa-IR')}</span>
                  <span>{fa?'بودجه:':'Budget:'} {item.budgeted?.toLocaleString('fa-IR')}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
      {showNew && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-[hsl(var(--secondary))] rounded-2xl border border-[hsl(var(--border))] w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-bold">➕ {fa?'آیتم بودجه جدید':'New Budget Item'}</h2>
              <button onClick={() => setShowNew(false)} className="text-xl text-[hsl(var(--muted-foreground))]">✕</button>
            </div>
            <div className="space-y-3">
              <div><label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">{fa?'عنوان':'Title'}</label><input className={inp} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">{fa?'مبلغ بودجه':'Budget Amount'}</label><input type="number" className={inp} /></div>
                <div><label className="text-xs font-medium text-[hsl(var(--muted-foreground))] mb-1 block">{fa?'نوع':'Type'}</label>
                  <select className={inp}><option value="expense">{fa?'هزینه':'Expense'}</option><option value="revenue">{fa?'درآمد':'Revenue'}</option></select>
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setShowNew(false)} className="flex-1 px-4 py-2 rounded-lg border border-[hsl(var(--border))] text-sm">{fa?'انصراف':'Cancel'}</button>
              <button className="flex-1 px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm">✅ {fa?'ذخیره':'Save'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
