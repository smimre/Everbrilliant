'use client';
import { useLocaleStore } from '@/store/locale.store';

export function BalanceSheet() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const totalAssets = 0, totalLiab = 0, totalEquity = 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">📊 {fa ? 'ترازنامه' : 'Balance Sheet'}</h1>
        <button className="px-4 py-2 rounded-lg border border-[hsl(var(--border))] text-sm">🖨️ {fa?'چاپ':'Print'}</button>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="rounded-xl border border-blue-500/30 bg-blue-500/5 p-4">
          <h3 className="font-bold text-blue-600 mb-3">🏛️ {fa?'دارایی‌ها':'Assets'}</h3>
          <div className="text-center py-4 text-[hsl(var(--muted-foreground))]"><div className="text-2xl mb-1">0</div><div className="text-xs">{fa?'ریال':'IRR'}</div></div>
        </div>
        <div className="space-y-3">
          <div className="rounded-xl border border-red-500/30 bg-red-500/5 p-4">
            <h3 className="font-bold text-red-500 mb-2">📤 {fa?'بدهی‌ها':'Liabilities'}</h3>
            <div className="text-lg font-bold text-red-500">0</div>
          </div>
          <div className="rounded-xl border border-purple-500/30 bg-purple-500/5 p-4">
            <h3 className="font-bold text-purple-600 mb-2">⚖️ {fa?'حقوق صاحبان سهام':'Equity'}</h3>
            <div className="text-lg font-bold text-purple-600">0</div>
          </div>
        </div>
      </div>
      {totalAssets !== totalLiab + totalEquity && totalAssets > 0 && (
        <div className="rounded-xl bg-red-500/10 border border-red-500/30 p-3 text-sm text-red-500">
          ⚠️ {fa?'ترازنامه متعادل نیست!':'Balance sheet is not balanced!'}
        </div>
      )}
    </div>
  );
}
