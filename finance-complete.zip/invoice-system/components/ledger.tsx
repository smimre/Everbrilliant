'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';

export function Ledger() {
  const { lang } = useLocaleStore();
  const fa = lang === 'fa';
  const [accounts] = useState<any[]>([]);
  const [selectedAcc, setSelectedAcc] = useState('');

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold">📔 {fa ? 'دفتر کل' : 'General Ledger'}</h1>
      <div className="flex gap-3">
        <select value={selectedAcc} onChange={e => setSelectedAcc(e.target.value)}
          className="flex-1 px-3 py-2 rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] text-sm focus:outline-none">
          <option value="">{fa ? '-- انتخاب حساب --' : '-- Select Account --'}</option>
          {accounts.map((a: any) => <option key={a.id} value={a.id}>{a.code} - {fa ? a.nameFa||a.name : a.name}</option>)}
        </select>
        <button className="px-4 py-2 rounded-lg bg-[hsl(var(--primary))] text-white text-sm">
          {fa ? 'نمایش' : 'Show'}
        </button>
      </div>
      {!selectedAcc ? (
        <div className="text-center py-16 text-[hsl(var(--muted-foreground))]">
          <div className="text-4xl mb-3">📔</div>
          <p className="font-medium">{fa ? 'یک حساب انتخاب کنید' : 'Select an account'}</p>
        </div>
      ) : (
        <div className="rounded-xl border border-[hsl(var(--border))] overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-[hsl(var(--muted)/0.5)]">
              <tr>
                {[fa?'تاریخ':'Date', fa?'شرح':'Description', fa?'بدهکار':'Debit', fa?'بستانکار':'Credit', fa?'مانده':'Balance'].map(h => (
                  <th key={h} className="text-start px-4 py-3 text-xs font-semibold text-[hsl(var(--muted-foreground))]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr><td colSpan={5} className="px-4 py-8 text-center text-[hsl(var(--muted-foreground))]">{fa?'سندی برای این حساب ثبت نشده':'No entries for this account'}</td></tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
