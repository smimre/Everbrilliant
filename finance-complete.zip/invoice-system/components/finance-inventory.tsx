'use client';
import { useLocaleStore } from '@/store/locale.store';
import { InventoryPage } from '../../trading/components/inventory';

export function FinanceInventory() {
  return <InventoryPage />;
}
