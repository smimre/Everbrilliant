'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { StatusBadge } from '@/components/dashboard/status-badge';
import { Table, Column } from '@/components/ui/table';
import type { Letter, WorkflowRequest, Meeting } from '@/types';
import { Plus, Mail, CheckSquare, Calendar, Archive, GitBranch } from 'lucide-react';

type AutoView = 'dashboard'|'letters'|'requests'|'meetings'|'tasks'|'archive'|'workflows';

export function AutomationModule() {
  const [view, setView] = useState<AutoView>('dashboard');
  const { lang } = useLocaleStore();

  if (view !== 'dashboard') {
    return (
      <div className="space-y-5">
        <Button variant="ghost" onClick={() => setView('dashboard')}>← {lang === 'fa' ? 'داشبورد' : 'Dashboard'}</Button>
        {view === 'letters'   && <LettersPage />}
        {view === 'requests'  && <WorkflowPage />}
        {view === 'meetings'  && <MeetingsPage />}
        {view === 'tasks'     && <TasksPage />}
      </div>
    );
  }

  const navItems = [
    { icon: <Mail className="h-6 w-6"/>, label_fa:'مکاتبات', label_en:'Correspondence', view:'letters' as AutoView, color:'#3b82f6' },
    { icon: <CheckSquare className="h-6 w-6"/>, label_fa:'درخواست‌ها', label_en:'Requests', view:'requests' as AutoView, color:'#8b5cf6' },
    { icon: <Calendar className="h-6 w-6"/>, label_fa:'جلسات', label_en:'Meetings', view:'meetings' as AutoView, color:'#10b981' },
    { icon: <CheckSquare className="h-6 w-6"/>, label_fa:'وظایف', label_en:'Tasks', view:'tasks' as AutoView, color:'#f59e0b' },
    { icon: <Archive className="h-6 w-6"/>, label_fa:'آرشیو', label_en:'Archive', view:'archive' as AutoView, color:'#06b6d4' },
    { icon: <GitBranch className="h-6 w-6"/>, label_fa:'گردش‌کار', label_en:'Workflows', view:'workflows' as AutoView, color:'#ec4899' },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">⚙️ {lang === 'fa' ? 'اتوماسیون اداری' : 'Office Automation'}</h1>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {navItems.map(item => (
          <button key={item.view} onClick={() => setView(item.view)}
            className="flex flex-col items-center gap-3 p-6 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] hover:border-[hsl(var(--primary)/0.4)] hover:bg-[hsl(var(--muted)/0.4)] transition-all group"
          >
            <div className="rounded-xl p-3 group-hover:scale-110 transition-transform" style={{ background:`${item.color}18`, color:item.color }}>{item.icon}</div>
            <span className="font-semibold text-sm">{lang==='fa'?item.label_fa:item.label_en}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function LettersPage() {
  const { lang } = useLocaleStore();
  const MOCK: Letter[] = [
    { id:'L-001', type:'incoming', title:'درخواست همکاری', letterNo:'1403/001', date:'1403/02/10', from:'شرکت الفا', to:'گروه رضایی', body:'', priority:'normal', status:'received', companyId:1, createdAt:'' },
    { id:'L-002', type:'outgoing', title:'پاسخ پیشنهاد', letterNo:'1403/002', date:'1403/02/12', from:'گروه رضایی', to:'شرکت الفا', body:'', priority:'urgent', status:'sent', companyId:1, createdAt:'' },
  ];
  const columns: Column<Letter>[] = [
    { key:'letterNo', header: lang==='fa'?'شماره نامه':'Letter #', render: v => <span className="font-mono text-xs font-bold text-[hsl(var(--primary))]">{v as string}</span> },
    { key:'title', header: lang==='fa'?'موضوع':'Subject', render: v => <span className="font-semibold">{v as string}</span> },
    { key:'type', header: lang==='fa'?'نوع':'Type', render: v => <Badge variant={v==='incoming'?'default':v==='outgoing'?'success':'secondary'}>{lang==='fa'?{incoming:'ورودی',outgoing:'خروجی',internal:'داخلی'}[v as string]||v as string:v as string}</Badge> },
    { key:'from', header: lang==='fa'?'از':'From' },
    { key:'to', header: lang==='fa'?'به':'To' },
    { key:'priority', header: lang==='fa'?'اولویت':'Priority', render: v => <Badge variant={v==='urgent'?'destructive':v==='confidential'?'warning':'secondary'}>{v as string}</Badge> },
    { key:'status', header: lang==='fa'?'وضعیت':'Status', render: v => <StatusBadge status={v as string} lang={lang}/> },
    { key:'date', header: lang==='fa'?'تاریخ':'Date', render: v => <span className="text-xs text-[hsl(var(--muted-foreground))]">{v as string}</span> },
  ];
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">✉️ {lang==='fa'?'مکاتبات':'Correspondence'}</h1>
        <Button><Plus className="h-4 w-4"/>{lang==='fa'?'نامه جدید':'New Letter'}</Button>
      </div>
      <Table columns={columns} data={MOCK} emptyTitle={lang==='fa'?'نامه‌ای پیدا نشد':'No letters'} emptyIcon="✉️"/>
    </div>
  );
}

function WorkflowPage() {
  const { lang } = useLocaleStore();
  const MOCK: WorkflowRequest[] = [
    { id:'WF-001', type:'leave', title:'مرخصی سالانه', requesterId:2, companyId:1, description:'درخواست ۳ روز مرخصی', status:'pending', startDate:'1403/03/01', endDate:'1403/03/03', createdAt:'' },
    { id:'WF-002', type:'advance', title:'پیش پرداخت حقوق', requesterId:3, companyId:1, description:'درخواست ۵ میلیون ریال', amount:5000000, currency:'IRR', status:'approved', createdAt:'' },
  ];
  const columns: Column<WorkflowRequest>[] = [
    { key:'id', header:'ID', render: v => <span className="font-mono text-xs font-bold text-[hsl(var(--primary))]">{v as string}</span> },
    { key:'title', header: lang==='fa'?'عنوان':'Title', render: v => <span className="font-semibold">{v as string}</span> },
    { key:'type', header: lang==='fa'?'نوع':'Type', render: v => <Badge variant="secondary">{lang==='fa'?{leave:'مرخصی',advance:'پیش‌پرداخت',purchase:'خرید',travel:'سفر',overtime:'اضافه‌کاری',other:'سایر'}[v as string]||v as string:v as string}</Badge> },
    { key:'status', header: lang==='fa'?'وضعیت':'Status', render: v => <StatusBadge status={v as string} lang={lang}/> },
    { key:'startDate', header: lang==='fa'?'از':'From', render: v => <span className="text-xs">{v as string||'—'}</span> },
    { key:'endDate', header: lang==='fa'?'تا':'To', render: v => <span className="text-xs">{v as string||'—'}</span> },
  ];
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">📋 {lang==='fa'?'درخواست‌های اداری':'Workflow Requests'}</h1>
        <Button><Plus className="h-4 w-4"/>{lang==='fa'?'درخواست جدید':'New Request'}</Button>
      </div>
      <Table columns={columns} data={MOCK} emptyTitle={lang==='fa'?'درخواستی پیدا نشد':'No requests'} emptyIcon="📋"/>
    </div>
  );
}

function MeetingsPage() {
  const { lang } = useLocaleStore();
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">🤝 {lang==='fa'?'جلسات':'Meetings'}</h1>
        <Button><Plus className="h-4 w-4"/>{lang==='fa'?'جلسه جدید':'New Meeting'}</Button>
      </div>
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-12 text-center text-[hsl(var(--muted-foreground))]">
        <p className="text-4xl mb-3">🤝</p>
        <p>{lang==='fa'?'هنوز جلسه‌ای ندارید':'No meetings scheduled'}</p>
      </div>
    </div>
  );
}

function TasksPage() {
  const { lang } = useLocaleStore();
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">✅ {lang==='fa'?'وظایف':'Tasks'}</h1>
        <Button><Plus className="h-4 w-4"/>{lang==='fa'?'وظیفه جدید':'New Task'}</Button>
      </div>
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-12 text-center text-[hsl(var(--muted-foreground))]">
        <p className="text-4xl mb-3">✅</p>
        <p>{lang==='fa'?'هنوز وظیفه‌ای ندارید':'No tasks yet'}</p>
      </div>
    </div>
  );
}
