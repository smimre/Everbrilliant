'use client';
import { useState } from 'react';
import { useLocaleStore } from '@/store/locale.store';
import { useRequests, useContracts, useTenders } from '@/hooks/use-trading';
import { Table, Column } from '@/components/ui/table';
import { StatusBadge } from '@/components/dashboard/status-badge';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { StatCard } from '@/components/dashboard/stat-card';
import { Pagination } from '@/components/ui/pagination';
import type { TradeRequest, Contract, Tender } from '@/types';
import { Plus, Search, ClipboardList, FileText, Gavel, Link2 } from 'lucide-react';

type TradingView = 'dashboard' | 'requests' | 'contracts' | 'tenders' | 'connections';

export function TradingModule() {
  const [view, setView] = useState<TradingView>('dashboard');
  const { lang } = useLocaleStore();

  const views: Record<TradingView, React.ReactNode> = {
    dashboard: <TradingDashboard onNavigate={setView} />,
    requests:   <RequestsList />,
    contracts:  <ContractsList />,
    tenders:    <TendersList />,
    connections:<ConnectionsPage />,
  };

  return (
    <div className="space-y-5">
      {view !== 'dashboard' && (
        <Button variant="ghost" onClick={() => setView('dashboard')}>← {lang === 'fa' ? 'داشبورد' : 'Dashboard'}</Button>
      )}
      {views[view]}
    </div>
  );
}

function TradingDashboard({ onNavigate }: { onNavigate: (v: TradingView) => void }) {
  const { lang } = useLocaleStore();
  const { data: reqs } = useRequests({ limit: 100 });
  const pending = reqs?.data?.filter(r => r.status === 'pending').length ?? 0;
  const approved = reqs?.data?.filter(r => r.status === 'approved').length ?? 0;
  const navItems = [
    { icon: <ClipboardList className="h-5 w-5"/>, label_fa:'درخواست‌ها', label_en:'Requests', view:'requests' as TradingView, color:'#3b82f6', count: reqs?.total },
    { icon: <FileText className="h-5 w-5"/>,      label_fa:'قراردادها',   label_en:'Contracts', view:'contracts' as TradingView, color:'#8b5cf6' },
    { icon: <Gavel className="h-5 w-5"/>,         label_fa:'مزایده‌ها',   label_en:'Tenders',  view:'tenders' as TradingView, color:'#f59e0b' },
    { icon: <Link2 className="h-5 w-5"/>,         label_fa:'اتصالات',     label_en:'Connections',view:'connections' as TradingView, color:'#10b981' },
  ];
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">📊 {lang === 'fa' ? 'داشبورد بازرگانی' : 'Trading Dashboard'}</h1>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={<ClipboardList className="h-5 w-5"/>} label={lang==='fa'?'درخواست در انتظار':'Pending'} value={pending} color="#f59e0b" />
        <StatCard icon={<ClipboardList className="h-5 w-5"/>} label={lang==='fa'?'تأیید شده':'Approved'} value={approved} color="#10b981" />
        <StatCard icon={<FileText className="h-5 w-5"/>} label={lang==='fa'?'قرارداد فعال':'Active Contracts'} value={5} color="#8b5cf6" />
        <StatCard icon={<Gavel className="h-5 w-5"/>} label={lang==='fa'?'مزایده باز':'Open Tenders'} value={3} color="#3b82f6" />
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {navItems.map(item => (
          <button key={item.view} onClick={() => onNavigate(item.view)}
            className="flex flex-col items-center gap-3 p-5 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] hover:border-[hsl(var(--primary)/0.4)] hover:bg-[hsl(var(--muted)/0.4)] transition-all group"
          >
            <div className="rounded-xl p-3 group-hover:scale-110 transition-transform" style={{ background:`${item.color}18`, color:item.color }}>{item.icon}</div>
            <div className="text-center">
              <p className="font-semibold text-sm">{lang==='fa'?item.label_fa:item.label_en}</p>
              {item.count !== undefined && <p className="text-xs text-[hsl(var(--muted-foreground))] mt-0.5">{item.count} {lang==='fa'?'مورد':'items'}</p>}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function RequestsList() {
  const { lang } = useLocaleStore();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const { data, isLoading } = useRequests({ page, limit: 15 });
  const fmt = (n?: number) => n ? new Intl.NumberFormat(lang==='fa'?'fa-IR':'en-US').format(Math.round(n/1_000_000))+'M' : '—';

  const columns: Column<TradeRequest>[] = [
    { key:'id', header:'ID', render: v => <span className="font-mono text-xs font-bold text-[hsl(var(--primary))]">{(v as string).slice(0,8)}…</span> },
    { key:'product', header: lang==='fa'?'کالا':'Product', render: v => <span className="font-semibold">{v as string}</span> },
    { key:'qty', header: lang==='fa'?'مقدار':'Qty', render: (v,row) => <span className="tabular-nums">{v as number} {row.unit}</span> },
    { key:'amountIRR', header: lang==='fa'?'مبلغ':'Amount', align:'end', render: v => <span className="font-bold tabular-nums">{fmt(v as number)}</span> },
    { key:'priority', header: lang==='fa'?'اولویت':'Priority', render: v => <Badge variant={v==='urgent'?'destructive':v==='high'?'warning':v==='low'?'secondary':'default'}>{v as string}</Badge> },
    { key:'status', header: lang==='fa'?'وضعیت':'Status', render: v => <StatusBadge status={v as string} lang={lang}/> },
    { key:'createdAt', header: lang==='fa'?'تاریخ':'Date', render: v => <span className="text-xs text-[hsl(var(--muted-foreground))]">{new Date(v as string).toLocaleDateString(lang==='fa'?'fa-IR':'en-US')}</span> },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">📋 {lang==='fa'?'درخواست‌ها':'Requests'}</h1>
        <Button><Plus className="h-4 w-4"/>{lang==='fa'?'درخواست جدید':'New Request'}</Button>
      </div>
      <Input placeholder={lang==='fa'?'جستجو...':'Search...'} value={search} onChange={e=>setSearch(e.target.value)} prefix={<Search className="h-4 w-4"/>} className="w-64"/>
      <Table columns={columns} data={data?.data??[]} loading={isLoading} emptyTitle={lang==='fa'?'درخواستی پیدا نشد':'No requests found'} emptyIcon="📋"/>
      <Pagination page={page} totalPages={data?.totalPages??1} onPageChange={setPage} showInfo total={data?.total} limit={15}/>
    </div>
  );
}

function ContractsList() {
  const { lang } = useLocaleStore();
  const { data, isLoading } = useContracts();
  const columns: Column<Contract>[] = [
    { key:'id', header:'ID', render: v => <span className="font-mono text-xs font-bold text-[hsl(var(--primary))]">{(v as string).slice(0,8)}…</span> },
    { key:'title', header: lang==='fa'?'عنوان':'Title', render: v => <span className="font-semibold">{v as string}</span> },
    { key:'amountIRR', header: lang==='fa'?'مبلغ':'Amount', render: v => <span className="font-bold tabular-nums">{new Intl.NumberFormat(lang==='fa'?'fa-IR':'en-US').format(Math.round((v as number)/1_000_000))}M</span> },
    { key:'status', header: lang==='fa'?'وضعیت':'Status', render: v => <StatusBadge status={v as string} lang={lang}/> },
    { key:'signedBuyer', header: lang==='fa'?'امضا خریدار':'Buyer Sign', render: v => v ? '✅' : '⏳' },
    { key:'signedSeller', header: lang==='fa'?'امضا فروشنده':'Seller Sign', render: v => v ? '✅' : '⏳' },
  ];
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">📝 {lang==='fa'?'قراردادها':'Contracts'}</h1>
        <Button><Plus className="h-4 w-4"/>{lang==='fa'?'قرارداد جدید':'New Contract'}</Button>
      </div>
      <Table columns={columns} data={data?.data??[]} loading={isLoading} emptyTitle={lang==='fa'?'قراردادی پیدا نشد':'No contracts'} emptyIcon="📝"/>
    </div>
  );
}

function TendersList() {
  const { lang } = useLocaleStore();
  const { data, isLoading } = useTenders();
  const columns: Column<Tender>[] = [
    { key:'id', header:'ID', render: v => <span className="font-mono text-xs font-bold text-[hsl(var(--primary))]">{(v as string).slice(0,8)}…</span> },
    { key:'title', header: lang==='fa'?'عنوان':'Title', render: v => <span className="font-semibold">{v as string}</span> },
    { key:'type', header: lang==='fa'?'نوع':'Type', render: v => <Badge variant="secondary">{v as string}</Badge> },
    { key:'startDate', header: lang==='fa'?'شروع':'Start' },
    { key:'endDate', header: lang==='fa'?'پایان':'End' },
    { key:'status', header: lang==='fa'?'وضعیت':'Status', render: v => <StatusBadge status={v as string} lang={lang}/> },
    { key:'bidsCount', header: lang==='fa'?'تعداد پیشنهاد':'Bids', align:'center', render: v => <Badge>{v as number ?? 0}</Badge> },
  ];
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">🔨 {lang==='fa'?'مزایده‌ها':'Tenders'}</h1>
        <Button><Plus className="h-4 w-4"/>{lang==='fa'?'مزایده جدید':'New Tender'}</Button>
      </div>
      <Table columns={columns} data={data?.data??[]} loading={isLoading} emptyTitle={lang==='fa'?'مزایده‌ای پیدا نشد':'No tenders'} emptyIcon="🔨"/>
    </div>
  );
}

function ConnectionsPage() {
  const { lang } = useLocaleStore();
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">🔗 {lang==='fa'?'اتصالات':'Connections'}</h1>
        <Button><Plus className="h-4 w-4"/>{lang==='fa'?'اتصال جدید':'New Connection'}</Button>
      </div>
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--secondary))] p-12 text-center text-[hsl(var(--muted-foreground))]">
        <p className="text-4xl mb-3">🔗</p>
        <p>{lang==='fa'?'هنوز اتصالی ندارید':'No connections yet'}</p>
      </div>
    </div>
  );
}
