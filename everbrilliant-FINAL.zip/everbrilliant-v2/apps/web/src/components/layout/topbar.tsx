'use client';
import { useUIStore } from '@/store/ui.store';
import { useAuthStore } from '@/store/auth.store';
import { useLocaleStore } from '@/store/locale.store';
import { LanguageSelector } from './language-selector';
import { Dropdown } from '@/components/ui/dropdown';
import { Avatar } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { Menu, Bell, Building2, ChevronDown } from 'lucide-react';
import { useRouter } from 'next/navigation';

type Module = 'trading' | 'finance' | 'automation';

const MODULE_LABELS = {
  trading:    { fa: '📊 بازرگانی',   en: '📊 Trading',    ar: '📊 تجارة' },
  finance:    { fa: '💰 مالی',        en: '💰 Finance',    ar: '💰 مالية' },
  automation: { fa: '⚙️ اتوماسیون',  en: '⚙️ Automation', ar: '⚙️ أتمتة' },
};

export function Topbar() {
  const { sidebarOpen, toggleSidebar, activeModule, setActiveModule } = useUIStore();
  const { user, clearAuth } = useAuthStore();
  const { lang } = useLocaleStore();
  const router = useRouter();

  const getLabel = (mod: Module) => MODULE_LABELS[mod][lang as keyof typeof MODULE_LABELS[Module]] || MODULE_LABELS[mod].en;

  return (
    <header className="h-14 flex items-center gap-3 px-4 border-b border-[hsl(var(--border))] bg-[hsl(var(--secondary)/0.8)] backdrop-blur-sm sticky top-0 z-30">

      {/* Hamburger */}
      <button
        onClick={toggleSidebar}
        className="rounded-lg p-2 text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] hover:bg-[hsl(var(--muted))] transition-colors"
      >
        <Menu className="h-5 w-5" />
      </button>

      {/* Logo */}
      <button onClick={() => router.push('/dashboard')} className="flex items-center gap-2 me-2 group">
        <div className="w-7 h-7 rounded-lg bg-[hsl(var(--primary))] flex items-center justify-center shadow-sm">
          <Building2 className="h-4 w-4 text-white" />
        </div>
        <span className="font-bold text-sm text-[hsl(var(--foreground))] group-hover:text-[hsl(var(--primary))] transition-colors">
          Everbrilliant
        </span>
      </button>

      {/* Module Switcher */}
      <div className="flex items-center gap-1 bg-[hsl(var(--muted)/0.5)] rounded-xl p-1">
        {(['trading', 'finance', 'automation'] as Module[]).map((mod) => (
          <button
            key={mod}
            onClick={() => setActiveModule(mod)}
            className={cn(
              'px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-150',
              activeModule === mod
                ? 'bg-[hsl(var(--primary))] text-white shadow-sm'
                : 'text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] hover:bg-[hsl(var(--muted))]'
            )}
          >
            {getLabel(mod)}
          </button>
        ))}
      </div>

      {/* Spacer */}
      <div className="flex-1" />

      {/* Language */}
      <LanguageSelector />

      {/* Notifications */}
      <button className="relative rounded-lg p-2 text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] hover:bg-[hsl(var(--muted))] transition-colors">
        <Bell className="h-5 w-5" />
        <span className="absolute top-1.5 end-1.5 h-2 w-2 rounded-full bg-[hsl(var(--destructive))]" />
      </button>

      {/* User Menu */}
      {user && (
        <Dropdown
          trigger={
            <button className="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-[hsl(var(--muted))] transition-colors">
              <Avatar name={user.name} size="sm" />
              <span className="hidden sm:block text-sm font-medium text-[hsl(var(--foreground))] max-w-[100px] truncate">
                {user.name}
              </span>
              <ChevronDown className="h-3.5 w-3.5 text-[hsl(var(--muted-foreground))]" />
            </button>
          }
          items={[
            { label: lang === 'fa' ? 'پروفایل' : 'Profile', onClick: () => router.push('/dashboard/profile') },
            { label: lang === 'fa' ? 'تنظیمات' : 'Settings', onClick: () => router.push('/dashboard/settings') },
            { separator: true },
            {
              label: lang === 'fa' ? 'خروج' : 'Sign Out',
              danger: true,
              onClick: () => { clearAuth(); router.replace('/login'); }
            },
          ]}
        />
      )}
    </header>
  );
}
