// ══════════════════════════════════════════════════════════════
// Integration Tests: Trading API
// ══════════════════════════════════════════════════════════════
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../../app.module';
import { PrismaService } from '../../prisma/prisma.service';
import * as bcrypt from 'bcrypt';

describe('Trading API (integration)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let token: string;
  let companyId: number;
  let requestId: string;

  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = module.createNestApplication();
    app.setGlobalPrefix('api');
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();

    prisma = module.get<PrismaService>(PrismaService);
    ({ token, companyId } = await seedTradingTestData(prisma));
  });

  afterAll(async () => {
    await cleanupTradingData(prisma, companyId);
    await app.close();
  });

  describe('GET /api/trading/requests', () => {
    it('should return paginated requests', async () => {
      const res = await request(app.getHttpServer())
        .get('/api/trading/requests')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(Array.isArray(res.body.data)).toBe(true);
      expect(res.body).toHaveProperty('total');
    });

    it('should filter by status', async () => {
      const res = await request(app.getHttpServer())
        .get('/api/trading/requests?status=PENDING')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      res.body.data.forEach((r: any) => {
        expect(r.status).toBe('PENDING');
      });
    });

    it('should paginate correctly', async () => {
      const res = await request(app.getHttpServer())
        .get('/api/trading/requests?page=1&limit=5')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(res.body.data.length).toBeLessThanOrEqual(5);
    });
  });

  describe('POST /api/trading/requests', () => {
    it('should create a new request', async () => {
      const res = await request(app.getHttpServer())
        .post('/api/trading/requests')
        .set('Authorization', `Bearer ${token}`)
        .send({
          product: 'Palm Oil RBD', qty: 20, unit: 'ton',
          currency: 'IRR', priority: 'high',
        })
        .expect(201);

      expect(res.body).toHaveProperty('id');
      expect(res.body.product).toBe('Palm Oil RBD');
      expect(res.body.status).toBe('PENDING');
      requestId = res.body.id;
    });

    it('should return 400 for missing required fields', async () => {
      await request(app.getHttpServer())
        .post('/api/trading/requests')
        .set('Authorization', `Bearer ${token}`)
        .send({ product: 'Test' })
        .expect(400);
    });
  });

  describe('PATCH /api/trading/requests/:id/cancel', () => {
    it('should cancel a request', async () => {
      const res = await request(app.getHttpServer())
        .patch(`/api/trading/requests/${requestId}/cancel`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(res.body.status).toBe('CANCELLED');
    });
  });

  describe('GET /api/trading/tenders', () => {
    it('should return open tenders', async () => {
      const res = await request(app.getHttpServer())
        .get('/api/trading/tenders')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(Array.isArray(res.body.data)).toBe(true);
    });
  });
});

async function seedTradingTestData(prisma: PrismaService) {
  const hash = await bcrypt.hash('Trade@1234', 12);
  const role = await prisma.role.findFirst({ where: { name: 'company_admin' } })
    || await prisma.role.create({ data: { name: 'company_admin', label: 'Admin' } });
  const company = await prisma.company.create({ data: { name: 'Trading Test Co' } });
  const user = await prisma.user.create({
    data: { name: 'Trade User', phone: '09199999910', password: hash, companyId: company.id, roleId: role.id, isCompanyAdmin: true },
  });

  // Login to get token
  const jwt = require('jsonwebtoken');
  const token = jwt.sign(
    { sub: user.id, phone: user.phone, companyId: company.id, role: 'company_admin', permissions: [] },
    process.env.JWT_SECRET || 'test-secret',
    { expiresIn: '1h' }
  );
  await prisma.session.create({ data: { userId: user.id, token, expiresAt: new Date(Date.now() + 3600000) } });

  return { token, companyId: company.id };
}

async function cleanupTradingData(prisma: PrismaService, companyId: number) {
  await prisma.tradeRequest.deleteMany({ where: { buyerCompanyId: companyId } });
  await prisma.user.deleteMany({ where: { companyId } });
  await prisma.company.delete({ where: { id: companyId } });
}
