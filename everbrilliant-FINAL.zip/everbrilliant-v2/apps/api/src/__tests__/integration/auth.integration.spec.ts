// ══════════════════════════════════════════════════════════════
// Integration Tests: Auth API Endpoints
// ══════════════════════════════════════════════════════════════
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../../app.module';
import { PrismaService } from '../../prisma/prisma.service';
import * as bcrypt from 'bcrypt';

describe('Auth API (integration)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let accessToken: string;

  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = module.createNestApplication();
    app.setGlobalPrefix('api');
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();

    prisma = module.get<PrismaService>(PrismaService);
    await seedTestData(prisma);
  });

  afterAll(async () => {
    await cleanupTestData(prisma);
    await app.close();
  });

  // ── POST /api/auth/login ──────────────────────────────────────
  describe('POST /api/auth/login', () => {
    it('should return 200 and tokens for valid credentials', async () => {
      const res = await request(app.getHttpServer())
        .post('/api/auth/login')
        .send({ phone: '09199999901', password: 'Test@1234' })
        .expect(200);

      expect(res.body).toHaveProperty('accessToken');
      expect(res.body).toHaveProperty('user');
      expect(res.body.user.phone).toBe('09199999901');
      accessToken = res.body.accessToken;
    });

    it('should return 401 for wrong password', async () => {
      await request(app.getHttpServer())
        .post('/api/auth/login')
        .send({ phone: '09199999901', password: 'WrongPass' })
        .expect(401);
    });

    it('should return 401 for non-existent user', async () => {
      await request(app.getHttpServer())
        .post('/api/auth/login')
        .send({ phone: '09100000000', password: 'Any@123' })
        .expect(401);
    });

    it('should return 400 for missing fields', async () => {
      await request(app.getHttpServer())
        .post('/api/auth/login')
        .send({ phone: '09199999901' })
        .expect(400);
    });
  });

  // ── GET /api/auth/me ─────────────────────────────────────────
  describe('GET /api/auth/me', () => {
    it('should return user profile with valid token', async () => {
      const res = await request(app.getHttpServer())
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      expect(res.body).toHaveProperty('id');
      expect(res.body).toHaveProperty('name');
    });

    it('should return 401 without token', async () => {
      await request(app.getHttpServer())
        .get('/api/auth/me')
        .expect(401);
    });

    it('should return 401 with invalid token', async () => {
      await request(app.getHttpServer())
        .get('/api/auth/me')
        .set('Authorization', 'Bearer invalid.token.here')
        .expect(401);
    });
  });

  // ── POST /api/auth/register ───────────────────────────────────
  describe('POST /api/auth/register', () => {
    it('should register new user and return tokens', async () => {
      const res = await request(app.getHttpServer())
        .post('/api/auth/register')
        .send({
          name: 'Test User', phone: '09199999902',
          password: 'NewUser@1234', companyName: 'Test Company',
        })
        .expect(201);

      expect(res.body).toHaveProperty('accessToken');
    });

    it('should return 400 for duplicate phone', async () => {
      await request(app.getHttpServer())
        .post('/api/auth/register')
        .send({ name: 'Duplicate', phone: '09199999901', password: 'Test@1234' })
        .expect(400);
    });
  });

  // ── POST /api/auth/logout ─────────────────────────────────────
  describe('POST /api/auth/logout', () => {
    it('should logout and invalidate token', async () => {
      await request(app.getHttpServer())
        .post('/api/auth/logout')
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      // Token should be invalid after logout
      await request(app.getHttpServer())
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(401);
    });
  });
});

// ── Helpers ───────────────────────────────────────────────────
async function seedTestData(prisma: PrismaService) {
  const hash = await bcrypt.hash('Test@1234', 12);

  const role = await prisma.role.findFirst({ where: { name: 'company_admin' } })
    || await prisma.role.create({ data: { name: 'company_admin', label: 'Admin' } });

  const company = await prisma.company.create({ data: { name: 'Integration Test Co' } });

  await prisma.user.create({
    data: {
      name: 'Test User', phone: '09199999901', password: hash,
      companyId: company.id, roleId: role.id, isCompanyAdmin: true,
    },
  });
}

async function cleanupTestData(prisma: PrismaService) {
  await prisma.user.deleteMany({ where: { phone: { in: ['09199999901', '09199999902'] } } });
  await prisma.company.deleteMany({ where: { name: { in: ['Integration Test Co', 'Test Company'] } } });
}
