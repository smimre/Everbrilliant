// ══════════════════════════════════════════════════════════════
// Unit Tests: AuthService
// ══════════════════════════════════════════════════════════════
import { Test, TestingModule } from '@nestjs/testing';
import { AuthService } from '../../modules/auth/auth.service';
import { JwtService } from '@nestjs/jwt';
import { UnauthorizedException, ForbiddenException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';

// ── Mocks ─────────────────────────────────────────────────────
const mockPrisma = {
  user: {
    findUnique: jest.fn(),
    update: jest.fn(),
    create: jest.fn(),
  },
  company: { create: jest.fn() },
  role: { findFirst: jest.fn() },
  session: { create: jest.fn(), deleteMany: jest.fn(), findUnique: jest.fn() },
};

const mockJwt = {
  sign: jest.fn(() => 'mock.jwt.token'),
  verify: jest.fn(),
};

const HASHED_PASS = '$2b$12$mockhashedpassword123456789012';

describe('AuthService', () => {
  let service: AuthService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: 'PrismaService', useValue: mockPrisma },
        { provide: JwtService, useValue: mockJwt },
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
  });

  afterEach(() => jest.clearAllMocks());

  // ── login ────────────────────────────────────────────────────
  describe('login()', () => {
    const validUser = {
      id: 1, name: 'احمد رضایی', phone: '09121111111',
      password: HASHED_PASS, companyId: 1,
      company: { id: 1, name: 'Test Co' },
      role: { name: 'company_admin', permissions: [{ permission: { key: 'req_view' } }] },
    };

    it('should return tokens for valid credentials', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(validUser);
      mockPrisma.user.update.mockResolvedValue(validUser);
      mockPrisma.session.create.mockResolvedValue({ id: 1 });
      jest.spyOn(bcrypt, 'compare').mockResolvedValue(true as never);

      const result = await service.login({ phone: '09121111111', password: 'Admin@1234' });

      expect(result).toHaveProperty('accessToken');
      expect(result).toHaveProperty('user');
      expect(result.user.phone).toBe('09121111111');
      expect(mockPrisma.session.create).toHaveBeenCalledTimes(1);
    });

    it('should throw UnauthorizedException for wrong password', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(validUser);
      jest.spyOn(bcrypt, 'compare').mockResolvedValue(false as never);

      await expect(service.login({ phone: '09121111111', password: 'wrong' }))
        .rejects.toThrow(UnauthorizedException);
    });

    it('should throw UnauthorizedException for non-existent user', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(null);

      await expect(service.login({ phone: '09129999999', password: 'any' }))
        .rejects.toThrow(UnauthorizedException);
    });

    it('should lock account after 5 failed attempts', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(validUser);
      jest.spyOn(bcrypt, 'compare').mockResolvedValue(false as never);

      for (let i = 0; i < 5; i++) {
        try { await service.login({ phone: '09121111111', password: 'wrong' }); } catch {}
      }

      await expect(service.login({ phone: '09121111111', password: 'wrong' }))
        .rejects.toThrow(ForbiddenException);
    });
  });

  // ── logout ───────────────────────────────────────────────────
  describe('logout()', () => {
    it('should delete session', async () => {
      mockPrisma.session.deleteMany.mockResolvedValue({ count: 1 });
      await service.logout('token123');
      expect(mockPrisma.session.deleteMany).toHaveBeenCalledWith({ where: { token: 'token123' } });
    });
  });
});
