// ══════════════════════════════════════════════════════════════
// Unit Tests: CacheService
// ══════════════════════════════════════════════════════════════
import { Test } from '@nestjs/testing';
import { CacheService } from '../../cache/cache.service';
import { ConfigService } from '@nestjs/config';

describe('CacheService', () => {
  let service: CacheService;
  const store = new Map<string, string>();

  const mockRedis = {
    connect: jest.fn(), disconnect: jest.fn(),
    get: jest.fn(async (k: string) => store.get(k) ?? null),
    setEx: jest.fn(async (k: string, _ttl: number, v: string) => { store.set(k, v); }),
    del: jest.fn(async (...keys: string[]) => { keys.forEach(k => store.delete(k)); }),
    keys: jest.fn(async (pattern: string) => [...store.keys()].filter(k => k.startsWith(pattern.replace('*','')))),
    isOpen: true,
    on: jest.fn(),
  };

  beforeEach(async () => {
    store.clear();
    jest.resetModules();

    // Mock createClient
    jest.mock('redis', () => ({ createClient: () => mockRedis }));

    const module = await Test.createTestingModule({
      providers: [
        CacheService,
        { provide: ConfigService, useValue: { get: jest.fn(() => 'redis://localhost:6379') } },
      ],
    }).compile();

    service = module.get<CacheService>(CacheService);
    (service as any).client = mockRedis;
    (service as any).connected = true;
  });

  describe('get/set/del', () => {
    it('should store and retrieve values', async () => {
      await service.set('key:1', { name: 'test' }, 60);
      const result = await service.get<{ name: string }>('key:1');
      expect(result).toEqual({ name: 'test' });
    });

    it('should return null for missing key', async () => {
      const result = await service.get('missing:key');
      expect(result).toBeNull();
    });

    it('should delete keys', async () => {
      await service.set('del:1', 'value');
      await service.del('del:1');
      expect(await service.get('del:1')).toBeNull();
    });
  });

  describe('getOrSet()', () => {
    it('should cache result of factory function', async () => {
      const factory = jest.fn(async () => ({ data: [1, 2, 3] }));
      const result1 = await service.getOrSet('or:set:1', factory, 60);
      const result2 = await service.getOrSet('or:set:1', factory, 60);

      expect(result1).toEqual({ data: [1, 2, 3] });
      expect(result2).toEqual({ data: [1, 2, 3] });
      // Factory should only be called once
      expect(factory).toHaveBeenCalledTimes(1);
    });
  });

  describe('KEYS', () => {
    it('should generate correct cache keys', () => {
      expect(service.KEYS.requests(1, 2)).toBe('req:1:2');
      expect(service.KEYS.invoice('INV-001')).toBe('inv:single:INV-001');
      expect(service.KEYS.employees(5)).toBe('emp:5');
    });
  });

  describe('graceful degradation', () => {
    it('should return null when Redis is unavailable', async () => {
      (service as any).connected = false;
      const result = await service.get('any:key');
      expect(result).toBeNull();
    });

    it('getOrSet should still work when Redis is down', async () => {
      (service as any).connected = false;
      const factory = jest.fn(async () => 'fresh_data');
      const result = await service.getOrSet('key', factory);
      expect(result).toBe('fresh_data');
      expect(factory).toHaveBeenCalled();
    });
  });
});
