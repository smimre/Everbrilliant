// ══════════════════════════════════════════════════════════════
// Unit Tests: PaginationPipe + QueryBuilder + paginated()
// ══════════════════════════════════════════════════════════════
import { PaginationPipe, paginated } from '../../common/pipes/pagination.pipe';
import { QueryBuilder, buildOrderBy } from '../../common/pipes/query-builder';

describe('PaginationPipe', () => {
  let pipe: PaginationPipe;

  beforeEach(() => { pipe = new PaginationPipe(); });

  it('returns default values for empty query', () => {
    const result = pipe.transform({});
    expect(result).toEqual({ page: 1, limit: 20, skip: 0, search: undefined, sortBy: undefined, sortOrder: 'desc' });
  });

  it('parses page and limit correctly', () => {
    const result = pipe.transform({ page: '3', limit: '10' });
    expect(result.page).toBe(3);
    expect(result.limit).toBe(10);
    expect(result.skip).toBe(20);
  });

  it('clamps limit to max 100', () => {
    const result = pipe.transform({ limit: '999' });
    expect(result.limit).toBe(100);
  });

  it('defaults page to 1 for invalid values', () => {
    expect(pipe.transform({ page: '-5' }).page).toBe(1);
    expect(pipe.transform({ page: 'abc' }).page).toBe(1);
    expect(pipe.transform({ page: '0' }).page).toBe(1);
  });

  it('extracts search term', () => {
    const result = pipe.transform({ search: '  Palm Oil  ' });
    expect(result.search).toBe('Palm Oil');
  });

  it('returns undefined search for empty string', () => {
    const result = pipe.transform({ search: '' });
    expect(result.search).toBeUndefined();
  });

  it('parses sortOrder', () => {
    expect(pipe.transform({ sortOrder: 'asc' }).sortOrder).toBe('asc');
    expect(pipe.transform({ sortOrder: 'desc' }).sortOrder).toBe('desc');
    expect(pipe.transform({ sortOrder: 'invalid' }).sortOrder).toBe('desc');
  });
});

describe('paginated()', () => {
  const items = Array.from({ length: 3 }, (_, i) => ({ id: i + 1, name: `Item ${i + 1}` }));
  const pagination = { page: 2, limit: 10, skip: 10, sortOrder: 'desc' as const };

  it('wraps data with correct meta', () => {
    const result = paginated(items, 23, pagination);
    expect(result.data).toHaveLength(3);
    expect(result.meta.total).toBe(23);
    expect(result.meta.page).toBe(2);
    expect(result.meta.limit).toBe(10);
    expect(result.meta.totalPages).toBe(3);
    expect(result.meta.hasNextPage).toBe(true);
    expect(result.meta.hasPrevPage).toBe(true);
  });

  it('sets hasNextPage=false on last page', () => {
    const result = paginated(items, 3, { ...pagination, page: 1 });
    expect(result.meta.hasNextPage).toBe(false);
  });

  it('sets hasPrevPage=false on first page', () => {
    const result = paginated(items, 30, { ...pagination, page: 1 });
    expect(result.meta.hasPrevPage).toBe(false);
  });
});

describe('QueryBuilder', () => {
  it('builds company filter', () => {
    const where = new QueryBuilder().forCompany(5).build();
    expect(where).toEqual({ companyId: 5 });
  });

  it('builds buyer/seller OR clause', () => {
    const where = new QueryBuilder().forBuyerOrSeller(3).build();
    expect(where).toEqual({ OR: [{ buyerCompanyId: 3 }, { sellerCompanyId: 3 }] });
  });

  it('builds search with multiple fields', () => {
    const where = new QueryBuilder()
      .search({ fields: ['product', 'note'], value: 'palm' })
      .build();
    expect(where).toHaveProperty('OR');
    expect((where.OR as any[]).length).toBe(2);
    expect((where.OR as any[])[0]).toEqual({ product: { contains: 'palm', mode: 'insensitive' } });
  });

  it('skips search when value is empty', () => {
    const where = new QueryBuilder().search({ fields: ['product'], value: '' }).build();
    expect(where).not.toHaveProperty('OR');
  });

  it('builds enum filter and uppercases value', () => {
    const where = new QueryBuilder().filter({ status: 'pending' }).build();
    expect(where).toEqual({ status: 'PENDING' });
  });

  it('skips undefined filter values', () => {
    const where = new QueryBuilder().filter({ status: undefined, priority: 'high' }).build();
    expect(where).not.toHaveProperty('status');
    expect(where).toHaveProperty('priority', 'HIGH');
  });

  it('builds date range', () => {
    const where = new QueryBuilder()
      .dateRange({ field: 'createdAt', from: '2024-01-01', to: '2024-12-31' })
      .build();
    expect(where.createdAt).toEqual({
      gte: new Date('2024-01-01'),
      lte: new Date('2024-12-31'),
    });
  });

  it('chains multiple builders', () => {
    const where = new QueryBuilder()
      .forCompany(1)
      .filter({ status: 'pending' })
      .search({ fields: ['name'], value: 'test' })
      .build();

    expect(where).toHaveProperty('companyId', 1);
    expect(where).toHaveProperty('status', 'PENDING');
    expect(where).toHaveProperty('OR');
  });
});

describe('buildOrderBy()', () => {
  it('returns default when no sortBy provided', () => {
    expect(buildOrderBy()).toEqual({ createdAt: 'desc' });
  });

  it('builds orderBy from params', () => {
    expect(buildOrderBy('name', 'asc')).toEqual({ name: 'asc' });
  });

  it('uses custom defaults', () => {
    expect(buildOrderBy(undefined, 'asc', { updatedAt: 'desc' })).toEqual({ updatedAt: 'desc' });
  });
});
