// ══════════════════════════════════════════════════════════════
// Unit Tests: AutomationService
// ══════════════════════════════════════════════════════════════
import { Test } from '@nestjs/testing';
import { AutomationService } from '../../modules/automation/automation.service';
import { NotFoundException } from '@nestjs/common';

const mockPrisma = {
  letter:          { findMany: jest.fn(), count: jest.fn(), create: jest.fn(), findFirst: jest.fn(), update: jest.fn() },
  workflowRequest: { findMany: jest.fn(), count: jest.fn(), create: jest.fn(), update: jest.fn() },
  approval:        { create: jest.fn(), findFirst: jest.fn(), update: jest.fn(), updateMany: jest.fn(), count: jest.fn() },
  meeting:         { findMany: jest.fn(), count: jest.fn(), create: jest.fn(), findFirst: jest.fn(), update: jest.fn() },
};

describe('AutomationService', () => {
  let service: AutomationService;

  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [AutomationService, { provide: 'PrismaService', useValue: mockPrisma }],
    }).compile();
    service = module.get<AutomationService>(AutomationService);
    (service as any).prisma = mockPrisma;
  });

  afterEach(() => jest.clearAllMocks());

  // ── Letters ────────────────────────────────────────────────
  describe('createLetter()', () => {
    it('auto-generates letter number', async () => {
      mockPrisma.letter.count.mockResolvedValue(5);
      mockPrisma.letter.create.mockImplementation(({ data }) =>
        Promise.resolve({ id: 'L-001', ...data })
      );

      const result = await service.createLetter(1, 99, {
        type: 'incoming', title: 'Test Letter', date: '1403/02/01',
        from: 'Company A', to: 'Company B', body: 'Hello', priority: 'normal',
        status: 'draft',
      } as any);

      expect(result.letterNo).toBe('1403/0006'); // count(5) + 1 = 6
      expect(mockPrisma.letter.create).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ type: 'INCOMING' }) })
      );
    });

    it('archives a letter correctly', async () => {
      mockPrisma.letter.findFirst.mockResolvedValue({ id: 'L-001', status: 'SENT' });
      mockPrisma.letter.update.mockResolvedValue({ id: 'L-001', status: 'ARCHIVED' });

      const result = await service.archiveLetter(1, 'L-001');
      expect(result.status).toBe('ARCHIVED');
      expect(mockPrisma.letter.update).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ status: 'ARCHIVED', archivedAt: expect.any(Date) }) })
      );
    });

    it('throws NotFoundException for unknown letter', async () => {
      mockPrisma.letter.findFirst.mockResolvedValue(null);
      await expect(service.archiveLetter(1, 'UNKNOWN')).rejects.toThrow(NotFoundException);
    });
  });

  // ── Workflow ───────────────────────────────────────────────
  describe('approveRequest()', () => {
    it('marks approval as APPROVED', async () => {
      mockPrisma.approval.findFirst.mockResolvedValue({ id: 'APR-001', requestId: 'WF-001' });
      mockPrisma.approval.update.mockResolvedValue({ id: 'APR-001', action: 'APPROVED' });
      mockPrisma.approval.count.mockResolvedValue(0); // no more pending
      mockPrisma.workflowRequest.update.mockResolvedValue({ id: 'WF-001', status: 'APPROVED' });

      await service.approveRequest(1, 99, 'WF-001', 'Looks good');

      expect(mockPrisma.approval.update).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ action: 'APPROVED', comment: 'Looks good' }) })
      );
    });

    it('sets request to APPROVED when no more pending approvals', async () => {
      mockPrisma.approval.findFirst.mockResolvedValue({ id: 'APR-001', requestId: 'WF-001' });
      mockPrisma.approval.update.mockResolvedValue({});
      mockPrisma.approval.count.mockResolvedValue(0); // all approved
      mockPrisma.workflowRequest.update.mockResolvedValue({ status: 'APPROVED' });

      await service.approveRequest(1, 99, 'WF-001');
      expect(mockPrisma.workflowRequest.update).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ status: 'APPROVED' }) })
      );
    });

    it('throws NotFoundException if no pending approval', async () => {
      mockPrisma.approval.findFirst.mockResolvedValue(null);
      await expect(service.approveRequest(1, 99, 'WF-001')).rejects.toThrow(NotFoundException);
    });
  });

  describe('rejectRequest()', () => {
    it('sets all approvals to REJECTED and request to REJECTED', async () => {
      mockPrisma.approval.updateMany.mockResolvedValue({ count: 1 });
      mockPrisma.workflowRequest.update.mockResolvedValue({ status: 'REJECTED' });

      await service.rejectRequest(1, 99, 'WF-001', 'Budget exceeded');

      expect(mockPrisma.approval.updateMany).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ action: 'REJECTED' }) })
      );
      expect(mockPrisma.workflowRequest.update).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ status: 'REJECTED' }) })
      );
    });
  });
});
