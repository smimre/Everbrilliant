// ══════════════════════════════════════════════════════════════
// Unit Tests: TradingService
// ══════════════════════════════════════════════════════════════
import { Test } from '@nestjs/testing';
import { TradingService } from '../../modules/trading/trading.service';
import { NotFoundException, ForbiddenException } from '@nestjs/common';

const mockPrisma = {
  tradeRequest: {
    findMany: jest.fn(), count: jest.fn(),
    findFirst: jest.fn(), create: jest.fn(),
    update: jest.fn(), updateMany: jest.fn(),
  },
  quote: {
    findMany: jest.fn(), findUnique: jest.fn(),
    create: jest.fn(), update: jest.fn(), updateMany: jest.fn(),
  },
  contract: {
    findMany: jest.fn(), count: jest.fn(),
    findUnique: jest.fn(), update: jest.fn(),
  },
  tender: {
    findMany: jest.fn(), count: jest.fn(),
    findUnique: jest.fn(), create: jest.fn(),
  },
  bid: { create: jest.fn() },
};

describe('TradingService', () => {
  let service: TradingService;

  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [TradingService, { provide: 'PrismaService', useValue: mockPrisma }],
    }).compile();
    service = module.get<TradingService>(TradingService);
    (service as any).prisma = mockPrisma;
  });

  afterEach(() => jest.clearAllMocks());

  // ── getRequests ────────────────────────────────────────────
  describe('getRequests()', () => {
    it('returns paginated requests for a company', async () => {
      mockPrisma.tradeRequest.findMany.mockResolvedValue([
        { id: 'REQ-001', product: 'Palm Oil', qty: 10, unit: 'ton', status: 'PENDING', priority: 'NORMAL', createdAt: new Date() },
      ]);
      mockPrisma.tradeRequest.count.mockResolvedValue(1);

      const result = await service.getRequests(1, {});

      expect(result.data).toHaveLength(1);
      expect(result.total).toBe(1);
      expect(mockPrisma.tradeRequest.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: expect.objectContaining({ OR: expect.any(Array) }) })
      );
    });

    it('filters by status', async () => {
      mockPrisma.tradeRequest.findMany.mockResolvedValue([]);
      mockPrisma.tradeRequest.count.mockResolvedValue(0);

      await service.getRequests(1, { status: 'PENDING' });

      expect(mockPrisma.tradeRequest.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: expect.objectContaining({ status: 'PENDING' }) })
      );
    });
  });

  // ── createRequest ──────────────────────────────────────────
  describe('createRequest()', () => {
    const dto = { product: 'Wheat', qty: 50, unit: 'ton', currency: 'IRR', priority: 'high' };

    it('creates a request and returns it', async () => {
      const mockResult = { id: 'REQ-NEW', ...dto, status: 'PENDING', buyerCompanyId: 1, createdById: 2 };
      mockPrisma.tradeRequest.create.mockResolvedValue(mockResult);

      const result = await service.createRequest(1, 2, dto);

      expect(result.product).toBe('Wheat');
      expect(mockPrisma.tradeRequest.create).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ buyerCompanyId: 1, createdById: 2 }) })
      );
    });
  });

  // ── cancelRequest ──────────────────────────────────────────
  describe('cancelRequest()', () => {
    it('cancels a request belonging to company', async () => {
      mockPrisma.tradeRequest.findFirst.mockResolvedValue({ id: 'REQ-001', buyerCompanyId: 1 });
      mockPrisma.tradeRequest.update.mockResolvedValue({ id: 'REQ-001', status: 'CANCELLED' });

      const result = await service.cancelRequest(1, 'REQ-001');
      expect(result.status).toBe('CANCELLED');
    });

    it('throws NotFoundException for unknown request', async () => {
      mockPrisma.tradeRequest.findFirst.mockResolvedValue(null);
      await expect(service.cancelRequest(1, 'UNKNOWN')).rejects.toThrow(NotFoundException);
    });
  });

  // ── acceptQuote ────────────────────────────────────────────
  describe('acceptQuote()', () => {
    it('accepts quote and rejects others', async () => {
      mockPrisma.quote.findUnique.mockResolvedValue({
        id: 'Q-001', requestId: 'REQ-001', sellerCompanyId: 2,
        request: { buyerCompanyId: 1 },
      });
      mockPrisma.quote.updateMany.mockResolvedValue({ count: 3 });
      mockPrisma.quote.update.mockResolvedValue({ id: 'Q-001', status: 'ACCEPTED' });
      mockPrisma.tradeRequest.update.mockResolvedValue({});

      const result = await service.acceptQuote(1, 'Q-001');

      expect(result.status).toBe('ACCEPTED');
      expect(mockPrisma.quote.updateMany).toHaveBeenCalledWith(
        expect.objectContaining({ data: { status: 'REJECTED' } })
      );
    });

    it('throws ForbiddenException if not buyer', async () => {
      mockPrisma.quote.findUnique.mockResolvedValue({
        id: 'Q-001', requestId: 'REQ-001', sellerCompanyId: 2,
        request: { buyerCompanyId: 99 },
      });
      await expect(service.acceptQuote(1, 'Q-001')).rejects.toThrow(ForbiddenException);
    });
  });

  // ── signContract ───────────────────────────────────────────
  describe('signContract()', () => {
    it('marks signedBuyer=true for buyer company', async () => {
      mockPrisma.contract.findUnique.mockResolvedValue({
        id: 'C-001', buyerCompanyId: 1, sellerCompanyId: 2,
        signedBuyer: false, signedSeller: false,
      });
      mockPrisma.contract.update.mockResolvedValue({ id: 'C-001', signedBuyer: true, signedSeller: false });

      const result = await service.signContract(1, 'C-001');
      expect(result.signedBuyer).toBe(true);
    });

    it('activates contract when both parties signed', async () => {
      mockPrisma.contract.findUnique.mockResolvedValue({
        id: 'C-001', buyerCompanyId: 1, sellerCompanyId: 2,
        signedBuyer: false, signedSeller: true,
      });
      // After update, both are true
      mockPrisma.contract.update
        .mockResolvedValueOnce({ id: 'C-001', signedBuyer: true, signedSeller: true })
        .mockResolvedValueOnce({ id: 'C-001', status: 'ACTIVE' });

      await service.signContract(1, 'C-001');
      expect(mockPrisma.contract.update).toHaveBeenCalledTimes(2);
    });

    it('throws NotFoundException for unknown contract', async () => {
      mockPrisma.contract.findUnique.mockResolvedValue(null);
      await expect(service.signContract(1, 'UNKNOWN')).rejects.toThrow(NotFoundException);
    });
  });
});
