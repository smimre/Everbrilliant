// ══════════════════════════════════════════════════════════════
// Unit Tests: NotificationsService
// ══════════════════════════════════════════════════════════════
import { Test } from '@nestjs/testing';
import { NotificationsService } from '../../modules/notifications/notifications.service';

const mockPrisma = {
  notification: {
    findMany: jest.fn(), count: jest.fn(),
    updateMany: jest.fn(), deleteMany: jest.fn(),
    create: jest.fn(),
  },
};

describe('NotificationsService', () => {
  let service: NotificationsService;

  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [NotificationsService, { provide: 'PrismaService', useValue: mockPrisma }],
    }).compile();
    service = module.get<NotificationsService>(NotificationsService);
    (service as any).prisma = mockPrisma;
  });

  afterEach(() => jest.clearAllMocks());

  describe('getAll()', () => {
    it('returns paginated notifications for user', async () => {
      const mockNotifs = [
        { id: 'N-001', userId: 1, type: 'INFO', title: 'Test', message: 'Hello', isRead: false },
      ];
      mockPrisma.notification.findMany.mockResolvedValue(mockNotifs);
      mockPrisma.notification.count.mockResolvedValue(1);

      const result = await service.getAll(1, 1, 20);

      expect(result.data).toHaveLength(1);
      expect(result.total).toBe(1);
      expect(mockPrisma.notification.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { userId: 1 } })
      );
    });
  });

  describe('getUnreadCount()', () => {
    it('returns count of unread notifications', async () => {
      mockPrisma.notification.count.mockResolvedValue(7);
      const result = await service.getUnreadCount(1);
      expect(result.count).toBe(7);
      expect(mockPrisma.notification.count).toHaveBeenCalledWith(
        { where: { userId: 1, isRead: false } }
      );
    });
  });

  describe('markRead()', () => {
    it('marks single notification as read', async () => {
      mockPrisma.notification.updateMany.mockResolvedValue({ count: 1 });
      await service.markRead(1, 'N-001');
      expect(mockPrisma.notification.updateMany).toHaveBeenCalledWith({
        where: { id: 'N-001', userId: 1 },
        data: { isRead: true, readAt: expect.any(Date) },
      });
    });
  });

  describe('markAllRead()', () => {
    it('marks all notifications as read', async () => {
      mockPrisma.notification.updateMany.mockResolvedValue({ count: 5 });
      await service.markAllRead(1);
      expect(mockPrisma.notification.updateMany).toHaveBeenCalledWith({
        where: { userId: 1, isRead: false },
        data: { isRead: true, readAt: expect.any(Date) },
      });
    });
  });

  describe('delete()', () => {
    it('deletes a notification by id', async () => {
      mockPrisma.notification.deleteMany.mockResolvedValue({ count: 1 });
      const result = await service.delete(1, 'N-001');
      expect(result.success).toBe(true);
    });
  });
});
