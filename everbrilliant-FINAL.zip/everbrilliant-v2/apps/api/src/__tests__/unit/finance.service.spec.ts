// ══════════════════════════════════════════════════════════════
// Unit Tests: FinanceService — Invoice calculation
// ══════════════════════════════════════════════════════════════
import { Test } from '@nestjs/testing';
import { FinanceService } from '../../modules/finance/finance.service';
import { NotFoundException, BadRequestException } from '@nestjs/common';

const mockPrisma = {
  invoice: {
    findMany: jest.fn(), count: jest.fn(),
    findFirst: jest.fn(), create: jest.fn(), update: jest.fn(),
  },
  payment: { create: jest.fn() },
  employee: { findMany: jest.fn(), count: jest.fn(), create: jest.fn() },
  inventoryItem: {
    findMany: jest.fn(), count: jest.fn(), create: jest.fn(),
    findFirst: jest.fn(), update: jest.fn(),
  },
  inventoryMovement: { create: jest.fn() },
};

describe('FinanceService', () => {
  let service: FinanceService;

  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [
        FinanceService,
        { provide: 'PrismaService', useValue: mockPrisma },
      ],
    }).compile();
    service = module.get<FinanceService>(FinanceService);
    (service as any).prisma = mockPrisma;
  });

  afterEach(() => jest.clearAllMocks());

  describe('createInvoice()', () => {
    const dto = {
      invoiceType: 'type1',
      buyerCompanyId: 2,
      issuedAt: '1403/02/15',
      items: [{
        desc: 'روغن پالم RBD', qty: 10, unit: 'تن',
        unitPrice: 100_000_000, discountPct: 0,
      }],
    };

    it('should calculate VAT (9%) and TOL (1%) correctly', async () => {
      mockPrisma.invoice.create.mockImplementation(({ data }) => Promise.resolve({ ...data, id: 'TEST-001' }));

      const result = await service.createInvoice(1, 99, dto);

      const subtotal = BigInt(10 * 100_000_000);
      const expectedVat = BigInt(Math.round(Number(subtotal) * 9 / 100));
      const expectedTol = BigInt(Math.round(Number(subtotal) * 1 / 100));
      const expectedTotal = subtotal + expectedVat + expectedTol;

      expect(result.subtotal).toBe(subtotal);
      expect(result.vatAmount).toBe(expectedVat);
      expect(result.tolAmount).toBe(expectedTol);
      expect(result.total).toBe(expectedTotal);
    });

    it('should apply discount correctly', async () => {
      const dtoWithDiscount = {
        ...dto,
        items: [{ ...dto.items[0], discountPct: 10 }],
      };
      mockPrisma.invoice.create.mockImplementation(({ data }) => Promise.resolve({ ...data }));

      const result = await service.createInvoice(1, 99, dtoWithDiscount);
      const subtotalAfterDiscount = BigInt(10 * 100_000_000) * BigInt(90) / BigInt(100);
      expect(result.subtotal).toBe(subtotalAfterDiscount);
    });
  });

  describe('stockMove()', () => {
    const mockItem = {
      id: 'item-1', companyId: 1, product: 'Test', qty: 100,
      unit: 'kg', minQty: 0, createdAt: new Date(),
    };

    it('should increase qty on stock-in', async () => {
      mockPrisma.inventoryItem.findFirst.mockResolvedValue(mockItem);
      mockPrisma.inventoryMovement.create.mockResolvedValue({});
      mockPrisma.inventoryItem.update.mockResolvedValue({ ...mockItem, qty: 150 });

      const result = await service.stockMove(1, 'item-1', 'in', 50, 99);
      expect(mockPrisma.inventoryItem.update).toHaveBeenCalledWith(
        expect.objectContaining({ data: { qty: 150 } })
      );
    });

    it('should throw BadRequestException when stock-out exceeds qty', async () => {
      mockPrisma.inventoryItem.findFirst.mockResolvedValue({ ...mockItem, qty: 10 });

      await expect(service.stockMove(1, 'item-1', 'out', 50, 99))
        .rejects.toThrow(BadRequestException);
    });

    it('should throw NotFoundException for unknown item', async () => {
      mockPrisma.inventoryItem.findFirst.mockResolvedValue(null);

      await expect(service.stockMove(1, 'unknown', 'in', 10, 99))
        .rejects.toThrow(NotFoundException);
    });
  });
});
