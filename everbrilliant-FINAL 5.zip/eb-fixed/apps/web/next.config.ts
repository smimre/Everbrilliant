import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  output: 'standalone',
  
  // Disable static generation completely - all pages are dynamic (require auth)
  // This fixes "Cannot access 'x' before initialization" in webpack chunks
  staticPageGenerationTimeout: 1000,

  transpilePackages: ['@everbrilliant/ui', '@everbrilliant/types'],

  images: {
    domains: ['localhost'],
    formats: ['image/avif', 'image/webp'],
    minimumCacheTTL: 3600,
    deviceSizes: [390, 640, 768, 1024, 1280, 1920],
  },

  experimental: {
    optimizePackageImports: ['lucide-react', '@tanstack/react-query'],
  },

  // Disable webpack minification that causes TDZ issues
  webpack(config, { isServer }) {
    if (!isServer) {
      config.optimization = {
        ...config.optimization,
        minimize: false,
      };
    }
    return config;
  },

  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
        ],
      },
    ];
  },

  async redirects() {
    return [
      { source: '/', destination: '/dashboard', permanent: false },
    ];
  },
};

export default nextConfig;
